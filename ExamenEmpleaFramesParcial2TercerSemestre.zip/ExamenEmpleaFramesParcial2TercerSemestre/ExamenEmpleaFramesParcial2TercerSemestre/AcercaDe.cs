﻿/*
 * Creado por SharpDevelop.
 * Usuario: olive
 * Fecha: 10/29/2025
 * Hora: 2:23 PM
 * 
 * Para cambiar esta plantilla use Herramientas | Opciones | Codificación | Editar Encabezados Estándar
 */
using System;
using System.Drawing;
using System.Windows.Forms;

namespace ExamenEmpleaFramesParcial2TercerSemestre
{
	/// <summary>
	/// Description of AcercaDe.
	/// </summary>
	public partial class AcercaDe : Form
	{
		public AcercaDe()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
		void BtnRegresarClick(object sender, EventArgs e)
		{
			this.Close();
		}
	}
}
