﻿/*
 * Creado por SharpDevelop.
 * Usuario: olive
 * Fecha: 10/29/2025
 * Hora: 1:11 PM
 * 
 * Para cambiar esta plantilla use Herramientas | Opciones | Codificación | Editar Encabezados Estándar
 */
namespace ExamenEmpleaFramesParcial2TercerSemestre
{
	partial class Principal
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Principal));
			this.menuStrip1 = new System.Windows.Forms.MenuStrip();
			this.archivoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.salirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.aplicacionesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.factorialToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.fibonacciToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.areaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.cuadradoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.areaToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
			this.trianguloToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.perimetroToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.circuferenciaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.trapecioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.volumenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.esferaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.cuboToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.piramideToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.conversionesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.longitudxToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.masaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.temperaturaCfToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.tiempoSegHorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.acercaDeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.formularioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.txtDato1 = new System.Windows.Forms.TextBox();
			this.lblResultado = new System.Windows.Forms.Label();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.txtDato2 = new System.Windows.Forms.TextBox();
			this.txtDato3 = new System.Windows.Forms.TextBox();
			this.lblDato1 = new System.Windows.Forms.Label();
			this.lblDato2 = new System.Windows.Forms.Label();
			this.lblDato3 = new System.Windows.Forms.Label();
			this.lblInstruccion = new System.Windows.Forms.Label();
			this.btnCalcular = new System.Windows.Forms.Button();
			this.lblDato4 = new System.Windows.Forms.Label();
			this.txtDato4 = new System.Windows.Forms.TextBox();
			this.menuStrip1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
			this.SuspendLayout();
			// 
			// menuStrip1
			// 
			this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
									this.archivoToolStripMenuItem,
									this.aplicacionesToolStripMenuItem,
									this.areaToolStripMenuItem,
									this.perimetroToolStripMenuItem,
									this.volumenToolStripMenuItem,
									this.conversionesToolStripMenuItem,
									this.acercaDeToolStripMenuItem});
			this.menuStrip1.Location = new System.Drawing.Point(0, 0);
			this.menuStrip1.Name = "menuStrip1";
			this.menuStrip1.Size = new System.Drawing.Size(703, 28);
			this.menuStrip1.TabIndex = 0;
			this.menuStrip1.Text = "menuStrip1";
			this.menuStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.MenuStrip1ItemClicked);
			// 
			// archivoToolStripMenuItem
			// 
			this.archivoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
									this.salirToolStripMenuItem});
			this.archivoToolStripMenuItem.Name = "archivoToolStripMenuItem";
			this.archivoToolStripMenuItem.Size = new System.Drawing.Size(71, 24);
			this.archivoToolStripMenuItem.Text = "Archivo";
			// 
			// salirToolStripMenuItem
			// 
			this.salirToolStripMenuItem.Name = "salirToolStripMenuItem";
			this.salirToolStripMenuItem.Size = new System.Drawing.Size(107, 24);
			this.salirToolStripMenuItem.Text = "Salir";
			this.salirToolStripMenuItem.Click += new System.EventHandler(this.SalirToolStripMenuItemClick);
			// 
			// aplicacionesToolStripMenuItem
			// 
			this.aplicacionesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
									this.factorialToolStripMenuItem,
									this.fibonacciToolStripMenuItem});
			this.aplicacionesToolStripMenuItem.Name = "aplicacionesToolStripMenuItem";
			this.aplicacionesToolStripMenuItem.Size = new System.Drawing.Size(105, 24);
			this.aplicacionesToolStripMenuItem.Text = "Aplicaciones";
			// 
			// factorialToolStripMenuItem
			// 
			this.factorialToolStripMenuItem.Name = "factorialToolStripMenuItem";
			this.factorialToolStripMenuItem.Size = new System.Drawing.Size(141, 24);
			this.factorialToolStripMenuItem.Text = "Factorial";
			this.factorialToolStripMenuItem.Click += new System.EventHandler(this.FactorialToolStripMenuItemClick);
			// 
			// fibonacciToolStripMenuItem
			// 
			this.fibonacciToolStripMenuItem.Name = "fibonacciToolStripMenuItem";
			this.fibonacciToolStripMenuItem.Size = new System.Drawing.Size(141, 24);
			this.fibonacciToolStripMenuItem.Text = "Fibonacci";
			this.fibonacciToolStripMenuItem.Click += new System.EventHandler(this.FibonacciToolStripMenuItemClick);
			// 
			// areaToolStripMenuItem
			// 
			this.areaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
									this.cuadradoToolStripMenuItem,
									this.areaToolStripMenuItem1,
									this.trianguloToolStripMenuItem});
			this.areaToolStripMenuItem.Name = "areaToolStripMenuItem";
			this.areaToolStripMenuItem.Size = new System.Drawing.Size(52, 24);
			this.areaToolStripMenuItem.Text = "Area";
			// 
			// cuadradoToolStripMenuItem
			// 
			this.cuadradoToolStripMenuItem.Name = "cuadradoToolStripMenuItem";
			this.cuadradoToolStripMenuItem.Size = new System.Drawing.Size(153, 24);
			this.cuadradoToolStripMenuItem.Text = "Cuadrado";
			this.cuadradoToolStripMenuItem.Click += new System.EventHandler(this.CuadradoToolStripMenuItemClick);
			// 
			// areaToolStripMenuItem1
			// 
			this.areaToolStripMenuItem1.Name = "areaToolStripMenuItem1";
			this.areaToolStripMenuItem1.Size = new System.Drawing.Size(153, 24);
			this.areaToolStripMenuItem1.Text = "Rectangulo";
			this.areaToolStripMenuItem1.Click += new System.EventHandler(this.AreaToolStripMenuItem1Click);
			// 
			// trianguloToolStripMenuItem
			// 
			this.trianguloToolStripMenuItem.Name = "trianguloToolStripMenuItem";
			this.trianguloToolStripMenuItem.Size = new System.Drawing.Size(153, 24);
			this.trianguloToolStripMenuItem.Text = "Triangulo";
			this.trianguloToolStripMenuItem.Click += new System.EventHandler(this.TrianguloToolStripMenuItemClick);
			// 
			// perimetroToolStripMenuItem
			// 
			this.perimetroToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
									this.circuferenciaToolStripMenuItem,
									this.trapecioToolStripMenuItem});
			this.perimetroToolStripMenuItem.Name = "perimetroToolStripMenuItem";
			this.perimetroToolStripMenuItem.Size = new System.Drawing.Size(85, 24);
			this.perimetroToolStripMenuItem.Text = "Perimetro";
			// 
			// circuferenciaToolStripMenuItem
			// 
			this.circuferenciaToolStripMenuItem.Name = "circuferenciaToolStripMenuItem";
			this.circuferenciaToolStripMenuItem.Size = new System.Drawing.Size(164, 24);
			this.circuferenciaToolStripMenuItem.Text = "Circuferencia";
			this.circuferenciaToolStripMenuItem.Click += new System.EventHandler(this.CircuferenciaToolStripMenuItemClick);
			// 
			// trapecioToolStripMenuItem
			// 
			this.trapecioToolStripMenuItem.Name = "trapecioToolStripMenuItem";
			this.trapecioToolStripMenuItem.Size = new System.Drawing.Size(164, 24);
			this.trapecioToolStripMenuItem.Text = "Trapecio";
			this.trapecioToolStripMenuItem.Click += new System.EventHandler(this.TrapecioToolStripMenuItemClick);
			// 
			// volumenToolStripMenuItem
			// 
			this.volumenToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
									this.esferaToolStripMenuItem,
									this.cuboToolStripMenuItem,
									this.piramideToolStripMenuItem});
			this.volumenToolStripMenuItem.Name = "volumenToolStripMenuItem";
			this.volumenToolStripMenuItem.Size = new System.Drawing.Size(79, 24);
			this.volumenToolStripMenuItem.Text = "Volumen";
			// 
			// esferaToolStripMenuItem
			// 
			this.esferaToolStripMenuItem.Name = "esferaToolStripMenuItem";
			this.esferaToolStripMenuItem.Size = new System.Drawing.Size(137, 24);
			this.esferaToolStripMenuItem.Text = "Esfera";
			this.esferaToolStripMenuItem.Click += new System.EventHandler(this.EsferaToolStripMenuItemClick);
			// 
			// cuboToolStripMenuItem
			// 
			this.cuboToolStripMenuItem.Name = "cuboToolStripMenuItem";
			this.cuboToolStripMenuItem.Size = new System.Drawing.Size(137, 24);
			this.cuboToolStripMenuItem.Text = "Cubo";
			this.cuboToolStripMenuItem.Click += new System.EventHandler(this.CuboToolStripMenuItemClick);
			// 
			// piramideToolStripMenuItem
			// 
			this.piramideToolStripMenuItem.Name = "piramideToolStripMenuItem";
			this.piramideToolStripMenuItem.Size = new System.Drawing.Size(137, 24);
			this.piramideToolStripMenuItem.Text = "Piramide";
			this.piramideToolStripMenuItem.Click += new System.EventHandler(this.PiramideToolStripMenuItemClick);
			// 
			// conversionesToolStripMenuItem
			// 
			this.conversionesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
									this.longitudxToolStripMenuItem,
									this.masaToolStripMenuItem,
									this.temperaturaCfToolStripMenuItem,
									this.tiempoSegHorToolStripMenuItem});
			this.conversionesToolStripMenuItem.Name = "conversionesToolStripMenuItem";
			this.conversionesToolStripMenuItem.Size = new System.Drawing.Size(108, 24);
			this.conversionesToolStripMenuItem.Text = "Conversiones";
			// 
			// longitudxToolStripMenuItem
			// 
			this.longitudxToolStripMenuItem.Name = "longitudxToolStripMenuItem";
			this.longitudxToolStripMenuItem.Size = new System.Drawing.Size(200, 24);
			this.longitudxToolStripMenuItem.Text = "Longitud Km-MI";
			this.longitudxToolStripMenuItem.Click += new System.EventHandler(this.LongitudxToolStripMenuItemClick);
			// 
			// masaToolStripMenuItem
			// 
			this.masaToolStripMenuItem.Name = "masaToolStripMenuItem";
			this.masaToolStripMenuItem.Size = new System.Drawing.Size(200, 24);
			this.masaToolStripMenuItem.Text = "Masa Kg-Lb";
			this.masaToolStripMenuItem.Click += new System.EventHandler(this.MasaToolStripMenuItemClick);
			// 
			// temperaturaCfToolStripMenuItem
			// 
			this.temperaturaCfToolStripMenuItem.Name = "temperaturaCfToolStripMenuItem";
			this.temperaturaCfToolStripMenuItem.Size = new System.Drawing.Size(200, 24);
			this.temperaturaCfToolStripMenuItem.Text = "Temperatura °C-°F";
			this.temperaturaCfToolStripMenuItem.Click += new System.EventHandler(this.TemperaturaCfToolStripMenuItemClick);
			// 
			// tiempoSegHorToolStripMenuItem
			// 
			this.tiempoSegHorToolStripMenuItem.Name = "tiempoSegHorToolStripMenuItem";
			this.tiempoSegHorToolStripMenuItem.Size = new System.Drawing.Size(200, 24);
			this.tiempoSegHorToolStripMenuItem.Text = "Tiempo Seg_Hor";
			this.tiempoSegHorToolStripMenuItem.Click += new System.EventHandler(this.TiempoSegHorToolStripMenuItemClick);
			// 
			// acercaDeToolStripMenuItem
			// 
			this.acercaDeToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
									this.formularioToolStripMenuItem});
			this.acercaDeToolStripMenuItem.Name = "acercaDeToolStripMenuItem";
			this.acercaDeToolStripMenuItem.Size = new System.Drawing.Size(87, 24);
			this.acercaDeToolStripMenuItem.Text = "Acerca de";
			// 
			// formularioToolStripMenuItem
			// 
			this.formularioToolStripMenuItem.Name = "formularioToolStripMenuItem";
			this.formularioToolStripMenuItem.Size = new System.Drawing.Size(150, 24);
			this.formularioToolStripMenuItem.Text = "Formulario";
			this.formularioToolStripMenuItem.Click += new System.EventHandler(this.FormularioToolStripMenuItemClick);
			// 
			// txtDato1
			// 
			this.txtDato1.Location = new System.Drawing.Point(12, 108);
			this.txtDato1.Name = "txtDato1";
			this.txtDato1.Size = new System.Drawing.Size(100, 22);
			this.txtDato1.TabIndex = 1;
			this.txtDato1.TextChanged += new System.EventHandler(this.TxtDato3TextChanged);
			// 
			// lblResultado
			// 
			this.lblResultado.BackColor = System.Drawing.Color.LightCyan;
			this.lblResultado.Font = new System.Drawing.Font("MingLiU_HKSCS-ExtB", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
			this.lblResultado.Location = new System.Drawing.Point(215, 180);
			this.lblResultado.Name = "lblResultado";
			this.lblResultado.Size = new System.Drawing.Size(403, 181);
			this.lblResultado.TabIndex = 2;
			// 
			// pictureBox1
			// 
			this.pictureBox1.BackColor = System.Drawing.Color.LightCyan;
			this.pictureBox1.Location = new System.Drawing.Point(12, 181);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(197, 180);
			this.pictureBox1.TabIndex = 3;
			this.pictureBox1.TabStop = false;
			// 
			// txtDato2
			// 
			this.txtDato2.Location = new System.Drawing.Point(135, 108);
			this.txtDato2.Name = "txtDato2";
			this.txtDato2.Size = new System.Drawing.Size(100, 22);
			this.txtDato2.TabIndex = 4;
			this.txtDato2.TextChanged += new System.EventHandler(this.TxtDato3TextChanged);
			// 
			// txtDato3
			// 
			this.txtDato3.Location = new System.Drawing.Point(266, 108);
			this.txtDato3.Name = "txtDato3";
			this.txtDato3.Size = new System.Drawing.Size(100, 22);
			this.txtDato3.TabIndex = 5;
			this.txtDato3.TextChanged += new System.EventHandler(this.TxtDato3TextChanged);
			// 
			// lblDato1
			// 
			this.lblDato1.BackColor = System.Drawing.Color.LightCyan;
			this.lblDato1.Font = new System.Drawing.Font("MingLiU_HKSCS-ExtB", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
			this.lblDato1.ForeColor = System.Drawing.Color.Fuchsia;
			this.lblDato1.Location = new System.Drawing.Point(12, 133);
			this.lblDato1.Name = "lblDato1";
			this.lblDato1.Size = new System.Drawing.Size(100, 23);
			this.lblDato1.TabIndex = 9;
			this.lblDato1.Text = "Dato 1";
			// 
			// lblDato2
			// 
			this.lblDato2.BackColor = System.Drawing.Color.LightCyan;
			this.lblDato2.Font = new System.Drawing.Font("MingLiU_HKSCS-ExtB", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
			this.lblDato2.ForeColor = System.Drawing.Color.Fuchsia;
			this.lblDato2.Location = new System.Drawing.Point(135, 135);
			this.lblDato2.Name = "lblDato2";
			this.lblDato2.Size = new System.Drawing.Size(100, 23);
			this.lblDato2.TabIndex = 10;
			this.lblDato2.Text = "Dato 2";
			// 
			// lblDato3
			// 
			this.lblDato3.BackColor = System.Drawing.Color.LightCyan;
			this.lblDato3.Font = new System.Drawing.Font("MingLiU_HKSCS-ExtB", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
			this.lblDato3.ForeColor = System.Drawing.Color.Fuchsia;
			this.lblDato3.Location = new System.Drawing.Point(266, 137);
			this.lblDato3.Name = "lblDato3";
			this.lblDato3.Size = new System.Drawing.Size(100, 23);
			this.lblDato3.TabIndex = 11;
			this.lblDato3.Text = "Dato 3";
			// 
			// lblInstruccion
			// 
			this.lblInstruccion.BackColor = System.Drawing.Color.LightCyan;
			this.lblInstruccion.Font = new System.Drawing.Font("MingLiU_HKSCS-ExtB", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
			this.lblInstruccion.ForeColor = System.Drawing.Color.DeepPink;
			this.lblInstruccion.Location = new System.Drawing.Point(12, 40);
			this.lblInstruccion.Name = "lblInstruccion";
			this.lblInstruccion.Size = new System.Drawing.Size(481, 65);
			this.lblInstruccion.TabIndex = 12;
			this.lblInstruccion.Text = "Instruccion:";
			// 
			// btnCalcular
			// 
			this.btnCalcular.Font = new System.Drawing.Font("MingLiU_HKSCS-ExtB", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnCalcular.ForeColor = System.Drawing.Color.Blue;
			this.btnCalcular.Location = new System.Drawing.Point(516, 55);
			this.btnCalcular.Name = "btnCalcular";
			this.btnCalcular.Size = new System.Drawing.Size(149, 59);
			this.btnCalcular.TabIndex = 13;
			this.btnCalcular.Text = "Calcular";
			this.btnCalcular.UseVisualStyleBackColor = true;
			this.btnCalcular.Click += new System.EventHandler(this.BtnCalcularClick);
			// 
			// lblDato4
			// 
			this.lblDato4.BackColor = System.Drawing.Color.LightCyan;
			this.lblDato4.Font = new System.Drawing.Font("MingLiU_HKSCS-ExtB", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
			this.lblDato4.ForeColor = System.Drawing.Color.Fuchsia;
			this.lblDato4.Location = new System.Drawing.Point(393, 137);
			this.lblDato4.Name = "lblDato4";
			this.lblDato4.Size = new System.Drawing.Size(100, 23);
			this.lblDato4.TabIndex = 15;
			this.lblDato4.Text = "Dato 4";
			// 
			// txtDato4
			// 
			this.txtDato4.Location = new System.Drawing.Point(393, 108);
			this.txtDato4.Name = "txtDato4";
			this.txtDato4.Size = new System.Drawing.Size(100, 22);
			this.txtDato4.TabIndex = 14;
			// 
			// Principal
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
			this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
			this.ClientSize = new System.Drawing.Size(703, 400);
			this.Controls.Add(this.lblDato4);
			this.Controls.Add(this.txtDato4);
			this.Controls.Add(this.btnCalcular);
			this.Controls.Add(this.lblInstruccion);
			this.Controls.Add(this.lblDato3);
			this.Controls.Add(this.lblDato2);
			this.Controls.Add(this.lblDato1);
			this.Controls.Add(this.txtDato3);
			this.Controls.Add(this.txtDato2);
			this.Controls.Add(this.pictureBox1);
			this.Controls.Add(this.lblResultado);
			this.Controls.Add(this.txtDato1);
			this.Controls.Add(this.menuStrip1);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MainMenuStrip = this.menuStrip1;
			this.MaximizeBox = false;
			this.Name = "Principal";
			this.Opacity = 0.85D;
			this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Principal";
			this.Load += new System.EventHandler(this.PrincipalLoad);
			this.menuStrip1.ResumeLayout(false);
			this.menuStrip1.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();
		}
		private System.Windows.Forms.TextBox txtDato4;
		private System.Windows.Forms.Label lblDato4;
		private System.Windows.Forms.Button btnCalcular;
		private System.Windows.Forms.Label lblInstruccion;
		private System.Windows.Forms.Label lblDato3;
		private System.Windows.Forms.Label lblDato2;
		private System.Windows.Forms.Label lblDato1;
		private System.Windows.Forms.TextBox txtDato3;
		private System.Windows.Forms.TextBox txtDato2;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.Label lblResultado;
		private System.Windows.Forms.TextBox txtDato1;
		private System.Windows.Forms.ToolStripMenuItem formularioToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem tiempoSegHorToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem temperaturaCfToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem masaToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem longitudxToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem piramideToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem cuboToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem esferaToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem trapecioToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem circuferenciaToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem trianguloToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem acercaDeToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem areaToolStripMenuItem1;
		private System.Windows.Forms.ToolStripMenuItem cuadradoToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem fibonacciToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem factorialToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem conversionesToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem volumenToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem perimetroToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem areaToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem aplicacionesToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem salirToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem archivoToolStripMenuItem;
		private System.Windows.Forms.MenuStrip menuStrip1;
	}
}
