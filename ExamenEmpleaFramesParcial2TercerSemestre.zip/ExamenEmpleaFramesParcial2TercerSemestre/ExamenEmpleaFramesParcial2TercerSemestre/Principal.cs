﻿/*
 * Creado por SharpDevelop.
 * Usuario: olive
 * Fecha: 10/29/2025
 * Hora: 1:11 PM
 * 
 * Para cambiar esta plantilla use Herramientas | Opciones | Codificación | Editar Encabezados Estándar
 */
using System;
using System.Drawing;
using System.Windows.Forms;

namespace ExamenEmpleaFramesParcial2TercerSemestre
{
	/// <summary>
	/// Description of Principal.
	/// </summary>
	public partial class Principal : Form
	{
	
private string ultimaOperacion = "";
private string rutaImagenes = @"C:\Users\olive\OneDrive\Documentos\SharpDevelop Projects\ExamenEmpleaFramesParcial2TercerSemestre\ExamenEmpleaFramesParcial2TercerSemestre\Fotografias\";

		public Principal()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
		void PrincipalLoad(object sender, EventArgs e)
		{
			
		}
		
		void MenuStrip1ItemClicked(object sender, ToolStripItemClickedEventArgs e)
		{
			
		}
		
		void AreaToolStripMenuItem1Click(object sender, EventArgs e)
		{
		
    ultimaOperacion = "rectangulo";

    lblDato1.Text = "Base:";
    lblDato2.Text = "Altura:";
    lblDato1.Visible = true; txtDato1.Visible = true;
    lblDato2.Visible = true; txtDato2.Visible = true;

    lblDato3.Visible = false; txtDato3.Visible = false;
    lblDato4.Visible = false; txtDato4.Visible = false;

    lblInstruccion.Text = "Introduca la base y alturitaw ,y luego presiona Calcular porfabowr";
    lblResultado.Text = "";
    string ruta = rutaImagenes + "Rectangulo.jpg";
if (System.IO.File.Exists(ruta))
{
    pictureBox1.Image = Image.FromFile(ruta);
    pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
}
else
{
    lblResultado.Text = "No se encontró la Imagensitaaw 😿: " + ruta;

    }

 
 
		}
		
		void LongitudxToolStripMenuItemClick(object sender, EventArgs e)
		{

    ultimaOperacion = "km_millas";

    lblDato1.Text = "Kilómetros:";
    lblDato1.Visible = true; txtDato1.Visible = true;

    lblDato2.Visible = false; txtDato2.Visible = false;
    lblDato3.Visible = false; txtDato3.Visible = false;
    lblDato4.Visible = false; txtDato4.Visible = false;

    lblInstruccion.Text = "Porfabowr escriba los kilometritows y presiona Calcular sisiis";
    lblResultado.Text = "";
	string ruta = rutaImagenes + "Le_Ssrafim.jpg";
if (System.IO.File.Exists(ruta))
{
    pictureBox1.Image = Image.FromFile(ruta);
    pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
}
else
{
    lblResultado.Text = "No se encontró la Imagensitaaw 😿: " + ruta;

    }
   
}			
		
		
		void TemperaturaCfToolStripMenuItemClick(object sender, EventArgs e)
		
{
   

    ultimaOperacion = "c_f";

    lblDato1.Text = "Grados °C:";
    lblDato1.Visible = true; txtDato1.Visible = true;

    lblDato2.Visible = false; txtDato2.Visible = false;
    lblDato3.Visible = false; txtDato3.Visible = false;
    lblDato4.Visible = false; txtDato4.Visible = false;

    lblInstruccion.Text = "Introduce graditows Celsius y presiona Calcular sipiwpw";
    lblResultado.Text = "";
	string ruta = rutaImagenes + "Le_Ssrafim.jpg";
if (System.IO.File.Exists(ruta))
{
    pictureBox1.Image = Image.FromFile(ruta);
    pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
}
else
{
    lblResultado.Text = "No se encontró la Imagensitaaw 😿: " + ruta;

    }
    
}			
		
		
		void SalirToolStripMenuItemClick(object sender, EventArgs e)
		
{
    DialogResult r = MessageBox.Show(
        "¿Desea salir de la aplicación miawsitowwrwr?",
        "Confirmar salidita ononowrwr",
        MessageBoxButtons.YesNo,
        MessageBoxIcon.Question
    );

    if (r == DialogResult.Yes)
    {
        Application.Exit();
    
}
		}
		
		void FactorialToolStripMenuItemClick(object sender, EventArgs e)
{

    ultimaOperacion = "factorial";

    lblDato1.Text = "Número:";
    lblDato1.Visible = true; txtDato1.Visible = true;

    lblDato2.Visible = false; txtDato2.Visible = false;
    lblDato3.Visible = false; txtDato3.Visible = false;
    lblDato4.Visible = false; txtDato4.Visible = false;

    lblInstruccion.Text = "Introduzca un numero nya y presiona Calcular porfi miawsitow";
    lblResultado.Text = "";

   
}				
		void FibonacciToolStripMenuItemClick(object sender, EventArgs e)
{

    ultimaOperacion = "fibonacci";

    lblDato1.Text = "Número:";
    lblDato1.Visible = true; txtDato1.Visible = true;

    lblDato2.Visible = false; txtDato2.Visible = false;
    lblDato3.Visible = false; txtDato3.Visible = false;
    lblDato4.Visible = false; txtDato4.Visible = false;

    lblInstruccion.Text = "Introduzca un numero nya y presiona Calcular porfi miawsitow";
    lblResultado.Text = "";

        

       
   
   
}
		
		void CuadradoToolStripMenuItemClick(object sender, EventArgs e)
		{


  
    ultimaOperacion = "rectangulo";

    lblDato1.Text = "Base:";
    lblDato2.Text = "Altura:";
    lblDato1.Visible = true; txtDato1.Visible = true;
    lblDato2.Visible = true; txtDato2.Visible = true;

    lblDato3.Visible = false; txtDato3.Visible = false;
    lblDato4.Visible = false; txtDato4.Visible = false;

    lblInstruccion.Text = "porfipwiw introduzca el ladito y oprimaaw Calcularr";
    lblResultado.Text = "";

   
  string ruta = rutaImagenes + "Cuadrado.jpg";
if (System.IO.File.Exists(ruta))
{
    pictureBox1.Image = Image.FromFile(ruta);
    pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
}
else
{
    lblResultado.Text = "No se encontró la Imagensitaaw 😿: " + ruta;

    }

}

   



		
		
		void FormularioToolStripMenuItemClick(object sender, EventArgs e)
		{
			AcercaDe acerca = new AcercaDe();
    acerca.ShowDialog();

		}
		
		void CircuferenciaToolStripMenuItemClick(object sender, EventArgs e)
		{
		
    ultimaOperacion = "circunferencia";

    lblDato1.Text = "Radio:";
    lblDato1.Visible = true; txtDato1.Visible = true;

    lblDato2.Visible = false; txtDato2.Visible = false;
    lblDato3.Visible = false; txtDato3.Visible = false;
    lblDato4.Visible = false; txtDato4.Visible = false;

    lblInstruccion.Text = "Introduce el radio porfiw y presiona Calcular iosioisiw";
    lblResultado.Text = "";
    string ruta = rutaImagenes + "Circunferencia.jpg";
if (System.IO.File.Exists(ruta))
{
    pictureBox1.Image = Image.FromFile(ruta);
    pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
}
else
{
    lblResultado.Text = "No se encontró la Imagensitaaw 😿: " + ruta;

    }
				
    
		}
		
		void EsferaToolStripMenuItemClick(object sender, EventArgs e)
		{
			
    ultimaOperacion = "esfera";

    lblDato1.Text = "Radio:";
    lblDato1.Visible = true; txtDato1.Visible = true;

    lblDato2.Visible = false; txtDato2.Visible = false;
    lblDato3.Visible = false; txtDato3.Visible = false;
    lblDato4.Visible = false; txtDato4.Visible = false;

    lblInstruccion.Text = "Introduce el radio de la esfera y presiona Calcular";
    lblResultado.Text = "";
    string ruta = rutaImagenes + "Esfera.jpg";
if (System.IO.File.Exists(ruta))
{
    pictureBox1.Image = Image.FromFile(ruta);
    pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
}
else
{
    lblResultado.Text = "No se encontró la Imagensitaaw 😿: " + ruta;

    }
	
    
		}
		
		void CuboToolStripMenuItemClick(object sender, EventArgs e)
		{
			
    ultimaOperacion = "cubo";

    
    lblDato1.Text = "Lado:";
    lblDato1.Visible = true; txtDato1.Visible = true;

    lblDato2.Visible = false; txtDato2.Visible = false;
    lblDato3.Visible = false; txtDato3.Visible = false;
    lblDato4.Visible = false; txtDato4.Visible = false;

    lblInstruccion.Text = "Introduce el lado del cubo y presiona Calcular";
    lblResultado.Text = "";
    string ruta = rutaImagenes + "Cubo.jpg";
if (System.IO.File.Exists(ruta))
{
    pictureBox1.Image = Image.FromFile(ruta);
    pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
}
else
{
    lblResultado.Text = "No se encontró la Imagensitaaw 😿: " + ruta;

    }

   
		}
		
		void PiramideToolStripMenuItemClick(object sender, EventArgs e)
		{
			
    ultimaOperacion = "piramide";

    lblDato1.Text = "Área base:";
    lblDato2.Text = "Altura:";
    lblDato1.Visible = true; txtDato1.Visible = true;
    lblDato2.Visible = true; txtDato2.Visible = true;

    lblDato3.Visible = false; txtDato3.Visible = false;
    lblDato4.Visible = false; txtDato4.Visible = false;

    lblInstruccion.Text = "Introduce law área base y alturtiaw porfabowr, luego presionew Calcular graciawas";
    lblResultado.Text = "";
    string ruta = rutaImagenes + "Piramide.jpg";
if (System.IO.File.Exists(ruta))
{
    pictureBox1.Image = Image.FromFile(ruta);
    pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
}
else
{
    lblResultado.Text = "No se encontró la Imagensitaaw 😿: " + ruta;

    }
}
   
	
		
		
		void TrianguloToolStripMenuItemClick(object sender, EventArgs e)
		{
		
    ultimaOperacion = "triangulo";

    lblDato1.Text = "Base:";
    lblDato2.Text = "Altura:";
    lblDato1.Visible = true; txtDato1.Visible = true;
    lblDato2.Visible = true; txtDato2.Visible = true;

    lblDato3.Visible = false; txtDato3.Visible = false;
    lblDato4.Visible = false; txtDato4.Visible = false;

    lblInstruccion.Text = "Introduce basitaw y alturitaaw, luego presiona Calcular sisiwiwi?";
    lblResultado.Text = "";
    
    string ruta = rutaImagenes + "Triangulo.jpg";
if (System.IO.File.Exists(ruta))
{
    pictureBox1.Image = Image.FromFile(ruta);
    pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
}
else
{
    lblResultado.Text = "No se encontró la Imagensitaaw 😿: " + ruta;

    }
}
   
		
		
		void TrapecioToolStripMenuItemClick(object sender, EventArgs e)
		{
			
    ultimaOperacion = "trapecio";

    lblDato1.Text = "Lado A:";
    lblDato2.Text = "Lado B:";
    lblDato3.Text = "Lado C:";
    lblDato4.Text = "Lado D:";
    lblDato1.Visible = true; txtDato1.Visible = true;
    lblDato2.Visible = true; txtDato2.Visible = true;
    lblDato3.Visible = true; txtDato3.Visible = true;
    lblDato4.Visible = true; txtDato4.Visible = true;

    lblInstruccion.Text = "Introduzca los 4 laditows y porfiw presionew Calcular";
    lblResultado.Text = "";
    string ruta = rutaImagenes + "Trapecio.jpg";
if (System.IO.File.Exists(ruta))
{
    pictureBox1.Image = Image.FromFile(ruta);
    pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
}
else
{
    lblResultado.Text = "No se encontró la Imagensitaaw 😿: " + ruta;

    }
}	
    
			
		
		
		void MasaToolStripMenuItemClick(object sender, EventArgs e)
		{
			
    ultimaOperacion = "kg_libras";

    lblDato1.Text = "Kilogramos:";
    lblDato1.Visible = true; txtDato1.Visible = true;

    lblDato2.Visible = false; txtDato2.Visible = false;
    lblDato3.Visible = false; txtDato3.Visible = false;
    lblDato4.Visible = false; txtDato4.Visible = false;

    lblInstruccion.Text = "Introduce kilogramitows y presiona Calcular porfipw";
    lblResultado.Text = "";
	string ruta = rutaImagenes + "Le_Ssrafim.jpg";
if (System.IO.File.Exists(ruta))
{
    pictureBox1.Image = Image.FromFile(ruta);
    pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
}
else
{
    lblResultado.Text = "No se encontró la Imagensitaaw 😿: " + ruta;

    }
   
		
		}
		
		void TiempoSegHorToolStripMenuItemClick(object sender, EventArgs e)	
{

    ultimaOperacion = "seg_horas";

    lblDato1.Text = "Segundos:";
    lblDato1.Visible = true; txtDato1.Visible = true;

    lblDato2.Visible = false; txtDato2.Visible = false;
    lblDato3.Visible = false; txtDato3.Visible = false;
    lblDato4.Visible = false; txtDato4.Visible = false;

    lblInstruccion.Text = "Introduce segundos y presiona Calcular";
    lblResultado.Text = "";
    	string ruta = rutaImagenes + "Le_Ssrafim.jpg";
if (System.IO.File.Exists(ruta))
{
    pictureBox1.Image = Image.FromFile(ruta);
    pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
}
else
{
    lblResultado.Text = "No se encontró la Imagensitaaw 😿: " + ruta;

    }

    }
			
		
		
		void TxtDato3TextChanged(object sender, EventArgs e)
		
{

		}

		
		void BtnCalcularClick(object sender, EventArgs e)
		{

    try
    {
        switch (ultimaOperacion)
        {

            case "factorial":
                int n = int.Parse(txtDato1.Text);
                long fact = 1;
                for (int i = 1; i <= n; i++) fact *= i;
                lblResultado.Text = "Factorial de " + n + " = " + fact;
                break;


            case "fibonacci":
                int f = int.Parse(txtDato1.Text);
                int a = 0, b = 1, temp;
                string serie = "0";
                for (int i = 1; i < f; i++)
                {
                    serie += ", " + b;
                    temp = a + b;
                    a = b;
                    b = temp;
                }
                lblResultado.Text = "Serie Fibonacci (" + f + " términos): " + serie;
                break;


            case "cuadrado":
                double lado = double.Parse(txtDato1.Text);
                lblResultado.Text = "Área del cuadrado = " + (lado * lado);
                break;

            case "rectangulo":
                double baseR = double.Parse(txtDato1.Text);
                double alturaR = double.Parse(txtDato2.Text);
                lblResultado.Text = "Área del rectángulo = " + (baseR * alturaR);
                break;

            case "triangulo":
                double baseT = double.Parse(txtDato1.Text);
                double alturaT = double.Parse(txtDato2.Text);
                lblResultado.Text = "Área del triángulo = " + ((baseT * alturaT) / 2);
                break;


            case "circunferencia":
                double radio = double.Parse(txtDato1.Text);
                lblResultado.Text = "Perímetro de la circunferencia = " + (2 * Math.PI * radio);
                break;

            case "trapecio":
                double a1 = double.Parse(txtDato1.Text);
                double a2 = double.Parse(txtDato2.Text);
                double a3 = double.Parse(txtDato3.Text);
                double a4 = double.Parse(txtDato4.Text);
                lblResultado.Text = "Perímetro del trapecio = " + (a1 + a2 + a3 + a4);
                break;


            case "cubo":
                double ladoC = double.Parse(txtDato1.Text);
                lblResultado.Text = "Volumen del cubo = " + Math.Pow(ladoC, 3);
                break;

            case "esfera":
                double r = double.Parse(txtDato1.Text);
                lblResultado.Text = "Volumen de la esfera = " + ((4.0 / 3.0) * Math.PI * Math.Pow(r, 3));
                break;

            case "piramide":
                double baseArea = double.Parse(txtDato1.Text);
                double alturaP = double.Parse(txtDato2.Text);
                lblResultado.Text = "Volumen de la pirámide = " + ((baseArea * alturaP) / 3);
                break;


            case "km_millas":
                double km = double.Parse(txtDato1.Text);
                lblResultado.Text = km + " km = " + (km * 0.621371) + " millas";
                break;

            case "kg_libras":
                double kg = double.Parse(txtDato1.Text);
                lblResultado.Text = kg + " kg = " + (kg * 2.20462) + " libras";
                break;

            case "c_f":
                double c = double.Parse(txtDato1.Text);
                lblResultado.Text = c + " °C = " + ((c * 9 / 5) + 32) + " °F";
                break;

            case "seg_horas":
                double seg = double.Parse(txtDato1.Text);
                lblResultado.Text = seg + " segundos = " + (seg / 3600) + " horas";
                break;

            default:
                lblResultado.Text = "Selecciona primero una operación del menú.";
                break;
        }
    }
    catch
    {
        lblResultado.Text = "Error: ingrese valores numéricos válidos.";
    }

		}
		
		void Label1Click(object sender, EventArgs e)
		{
			
		}
}
}