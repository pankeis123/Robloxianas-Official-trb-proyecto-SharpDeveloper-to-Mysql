﻿/* 
 * Creado por SharpDevelop.
 * Usuario: olive
 * Fecha: 10/29/2025
 * Hora: 1:04 PM
 * 
 * Para cambiar esta plantilla use Herramientas | Opciones | Codificación | Editar Encabezados Estándar
 */
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace ExamenEmpleaFramesParcial2TercerSemestre
{
    /// <summary>
    /// Description of MainForm.
    /// </summary>
    public partial class frmSeguridad : Form
    {

        private int intentosFallidos = 0;


        public frmSeguridad()
        {
            InitializeComponent();
        }

        void MainFormLoad(object sender, EventArgs e)
        {
         txtContraseña.UseSystemPasswordChar = true;

        }

        void BtnEntrarClick(object sender, EventArgs e)
        {
            string usuarioValido = "Admin";
            string contraseñaValida = "123";


            if (txtUsuario.Text == usuarioValido && txtContraseña.Text == contraseñaValida)
            {

                Principal frm = new Principal();
                frm.Show();


                this.Hide();
            }
            else
            {
                intentosFallidos++;

                if (intentosFallidos < 4)
                {
                    MessageBox.Show(
                        string.Format("Usuario o contraseña incorrectos. Intento {0} de 3 permitidos onononow.", intentosFallidos),
                        "Error de acceso",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning
                    );

                    txtContraseña.Clear();
                    txtUsuario.Focus();
                }
                else
                {
                    MessageBox.Show(
                        "Ha superado el número máximo de intentos. La aplicación se cerrará losentowoow.",
                        "Acceso denegado",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Stop
                    );

                    Application.Exit();
                }
            }
        }
    }
}