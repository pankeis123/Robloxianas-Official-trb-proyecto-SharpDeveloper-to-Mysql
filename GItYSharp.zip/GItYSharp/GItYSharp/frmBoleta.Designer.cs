﻿/*
 * Creado por SharpDevelop.
 * Usuario: olive
 * Fecha: 12/14/2025
 * Hora: 8:55 PM
 * 
 * Para cambiar esta plantilla use Herramientas | Opciones | Codificación | Editar Encabezados Estándar
 */
namespace GItYSharp
{
	partial class frmBoleta
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			System.Windows.Forms.ListViewItem listViewItem1 = new System.Windows.Forms.ListViewItem("Materia");
			System.Windows.Forms.ListViewItem listViewItem2 = new System.Windows.Forms.ListViewItem("Parcial 1");
			System.Windows.Forms.ListViewItem listViewItem3 = new System.Windows.Forms.ListViewItem("Parcial 2");
			System.Windows.Forms.ListViewItem listViewItem4 = new System.Windows.Forms.ListViewItem("Parcial 3");
			System.Windows.Forms.ListViewItem listViewItem5 = new System.Windows.Forms.ListViewItem("Promedio");
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.txtMateria = new System.Windows.Forms.TextBox();
			this.txtP3 = new System.Windows.Forms.TextBox();
			this.txtP2 = new System.Windows.Forms.TextBox();
			this.txtP1 = new System.Windows.Forms.TextBox();
			this.btnAgregar = new System.Windows.Forms.Button();
			this.btnEliminar = new System.Windows.Forms.Button();
			this.lvBoleta = new System.Windows.Forms.ListView();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(24, 80);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(100, 23);
			this.label1.TabIndex = 0;
			this.label1.Text = "Materia";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(178, 80);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(100, 23);
			this.label2.TabIndex = 1;
			this.label2.Text = "Parcial 1";
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(300, 80);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(100, 23);
			this.label3.TabIndex = 2;
			this.label3.Text = "parcial 2";
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(419, 80);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(100, 23);
			this.label4.TabIndex = 3;
			this.label4.Text = "parcial 3";
			// 
			// txtMateria
			// 
			this.txtMateria.Location = new System.Drawing.Point(12, 115);
			this.txtMateria.Name = "txtMateria";
			this.txtMateria.Size = new System.Drawing.Size(100, 22);
			this.txtMateria.TabIndex = 4;
			// 
			// txtP3
			// 
			this.txtP3.Location = new System.Drawing.Point(409, 115);
			this.txtP3.Name = "txtP3";
			this.txtP3.Size = new System.Drawing.Size(100, 22);
			this.txtP3.TabIndex = 5;
			// 
			// txtP2
			// 
			this.txtP2.Location = new System.Drawing.Point(285, 115);
			this.txtP2.Name = "txtP2";
			this.txtP2.Size = new System.Drawing.Size(100, 22);
			this.txtP2.TabIndex = 6;
			// 
			// txtP1
			// 
			this.txtP1.Location = new System.Drawing.Point(168, 115);
			this.txtP1.Name = "txtP1";
			this.txtP1.Size = new System.Drawing.Size(100, 22);
			this.txtP1.TabIndex = 7;
			// 
			// btnAgregar
			// 
			this.btnAgregar.Location = new System.Drawing.Point(28, 214);
			this.btnAgregar.Name = "btnAgregar";
			this.btnAgregar.Size = new System.Drawing.Size(75, 33);
			this.btnAgregar.TabIndex = 8;
			this.btnAgregar.Text = "Agregar";
			this.btnAgregar.UseVisualStyleBackColor = true;
			// 
			// btnEliminar
			// 
			this.btnEliminar.Location = new System.Drawing.Point(109, 214);
			this.btnEliminar.Name = "btnEliminar";
			this.btnEliminar.Size = new System.Drawing.Size(75, 33);
			this.btnEliminar.TabIndex = 9;
			this.btnEliminar.Text = "Eliminar";
			this.btnEliminar.UseVisualStyleBackColor = true;
			// 
			// lvBoleta
			// 
			this.lvBoleta.FullRowSelect = true;
			this.lvBoleta.GridLines = true;
			this.lvBoleta.HideSelection = false;
			this.lvBoleta.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
									listViewItem1,
									listViewItem2,
									listViewItem3,
									listViewItem4,
									listViewItem5});
			this.lvBoleta.Location = new System.Drawing.Point(28, 272);
			this.lvBoleta.Name = "lvBoleta";
			this.lvBoleta.Size = new System.Drawing.Size(583, 97);
			this.lvBoleta.TabIndex = 10;
			this.lvBoleta.UseCompatibleStateImageBehavior = false;
			this.lvBoleta.View = System.Windows.Forms.View.Details;
			// 
			// frmBoleta
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(724, 453);
			this.Controls.Add(this.lvBoleta);
			this.Controls.Add(this.btnEliminar);
			this.Controls.Add(this.btnAgregar);
			this.Controls.Add(this.txtP1);
			this.Controls.Add(this.txtP2);
			this.Controls.Add(this.txtP3);
			this.Controls.Add(this.txtMateria);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Name = "frmBoleta";
			this.Text = "frmBoleta";
			this.ResumeLayout(false);
			this.PerformLayout();
		}
		private System.Windows.Forms.ListView lvBoleta;
		private System.Windows.Forms.Button btnEliminar;
		private System.Windows.Forms.Button btnAgregar;
		private System.Windows.Forms.TextBox txtP1;
		private System.Windows.Forms.TextBox txtP2;
		private System.Windows.Forms.TextBox txtP3;
		private System.Windows.Forms.TextBox txtMateria;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label1;
	}
}
