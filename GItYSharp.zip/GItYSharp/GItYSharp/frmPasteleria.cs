﻿using System;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace GItYSharp
{
    public partial class frmPasteleria : Form
    {
        private string connectionString = "Server=localhost;Database=sistema_tienda;Uid=root;Pwd=root09218743;";

        public frmPasteleria()
        {
            InitializeComponent();
            rbDulce.CheckedChanged += Tipo_CheckedChanged;
            rbSalado.CheckedChanged += Tipo_CheckedChanged;
            cboProducto.SelectedIndexChanged += CboProducto_SelectedIndexChanged;
            btnAgregar.Click += BtnAgregar_Click;
            btnGuardar.Click += BtnGuardar_Click;
            btnEliminar.Click += BtnEliminar_Click;
            btnImprimir.Click += BtnImprimir_Click;


            txtPagado.TextChanged += (s, e) => CalcularTotales();
            
        }


        private void Tipo_CheckedChanged(object sender, EventArgs e)
        {
            string tipo = "";
            if (rbDulce.Checked)
                tipo = "Dulce";
            else if (rbSalado.Checked)
                tipo = "Salado";

            if (tipo == "") return;

            cboProducto.Items.Clear();
            try
            {
                using (MySqlConnection cn = new MySqlConnection(connectionString))
                {
                    cn.Open();
                    using (MySqlCommand cmd = new MySqlCommand("SELECT nombre FROM postres WHERE tipo=@tipo", cn))
                    {
                        cmd.Parameters.AddWithValue("@tipo", tipo);
                        using (MySqlDataReader dr = cmd.ExecuteReader())
                        {
                            while (dr.Read())
                                cboProducto.Items.Add(dr.GetString("nombre"));
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar productos: " + ex.Message);
            }
        }


        private void CboProducto_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cboProducto.SelectedItem == null) return;

            string nombre = cboProducto.SelectedItem.ToString();

            try
            {
                using (MySqlConnection cn = new MySqlConnection(connectionString))
                {
                    cn.Open();
                    using (MySqlCommand cmd = new MySqlCommand("SELECT precio FROM postres WHERE nombre=@nombre", cn))
                    {
                        cmd.Parameters.AddWithValue("@nombre", nombre);
                        object precio = cmd.ExecuteScalar();
                        txtPrecio.Text = Convert.ToDecimal(precio).ToString("0.00");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al obtener precio: " + ex.Message);
            }
        }


        private void BtnAgregar_Click(object sender, EventArgs e)
        {
            if (cboProducto.SelectedItem == null || string.IsNullOrEmpty(txtPrecio.Text) || string.IsNullOrEmpty(txtCantidad.Text))
            {
                MessageBox.Show("Seleccione un producto y cantidad válida");
                return;
            }

            string producto = cboProducto.SelectedItem.ToString();
            decimal precio = decimal.Parse(txtPrecio.Text);
            int cantidad = int.Parse(txtCantidad.Text);
            decimal total = precio * cantidad;

            ListViewItem item = new ListViewItem(producto);
            item.SubItems.Add(precio.ToString("0.00"));
            item.SubItems.Add(cantidad.ToString());
            item.SubItems.Add(total.ToString("0.00"));
            lvVenta.Items.Add(item);

            CalcularTotales();
        }


        private void CalcularTotales()
        {
            decimal subtotal = 0;
            foreach (ListViewItem item in lvVenta.Items)
                subtotal += decimal.Parse(item.SubItems[3].Text);

            decimal descuento = 0;

            decimal importeNeto = subtotal - descuento;

            decimal pagado = 0;
            decimal.TryParse(txtPagado.Text, out pagado);
            decimal cambio = pagado - importeNeto;

            lblTotal.Text = importeNeto.ToString("0.00");
            lblCambio.Text = cambio.ToString("0.00");


            if (pagado < importeNeto && pagado > subtotal)
            {
                lblCambio.Text = "0.00";
                MessageBox.Show("El monto pagado es insuficiente para cubrir el total.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        // Guardar venta en MySQL
        private void BtnGuardar_Click(object sender, EventArgs e)
        {
            if (lvVenta.Items.Count == 0)
            {
                MessageBox.Show("No hay productos en la venta");
                return;
            }

            try
            {
                using (MySqlConnection cn = new MySqlConnection(connectionString))
                {
                    cn.Open();
                    foreach (ListViewItem item in lvVenta.Items)
                    {
                        using (MySqlCommand cmd = new MySqlCommand(
                            "INSERT INTO ventas_pasteleria (producto, precio, cantidad, total, fecha) VALUES (@p,@pr,@c,@t,NOW())", cn))
                        {
                            cmd.Parameters.AddWithValue("@p", item.SubItems[0].Text);
                            cmd.Parameters.AddWithValue("@pr", decimal.Parse(item.SubItems[1].Text));
                            cmd.Parameters.AddWithValue("@c", int.Parse(item.SubItems[2].Text));
                            cmd.Parameters.AddWithValue("@t", decimal.Parse(item.SubItems[3].Text));
                            cmd.ExecuteNonQuery();
                        }
                    }
                }

                MessageBox.Show("Venta guardada correctamente");
                lvVenta.Items.Clear();
                LimpiarCampos();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al guardar venta: " + ex.Message);
            }
        }

        // Eliminar producto de la lista
        private void BtnEliminar_Click(object sender, EventArgs e)
        {
            if (lvVenta.SelectedItems.Count > 0)
                lvVenta.Items.Remove(lvVenta.SelectedItems[0]);

            CalcularTotales();
        }

        // Imprimir (pendiente)
        private void BtnImprimir_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Función de impresión aún no implementada 🖨️");
        }

        // Limpiar campos
        private void LimpiarCampos()
        {
            txtPrecio.Clear();
            txtCantidad.Clear();

            txtPagado.Clear();
            lblTotal.Text = "";
            lblCambio.Text = "";
            cboProducto.Items.Clear();
            rbDulce.Checked = false;
            rbSalado.Checked = false;
        }
    }
}