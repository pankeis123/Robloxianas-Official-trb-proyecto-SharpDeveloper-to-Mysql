﻿/*
 * Creado por SharpDevelop.
 * Usuario: olive
 * Fecha: 12/14/2025
 * Hora: 4:41 PM
 * 
 * Para cambiar esta plantilla use Herramientas | Opciones | Codificación | Editar Encabezados Estándar
 */
using System;
using System.Drawing;
using System.Windows.Forms;

namespace GItYSharp
{
	/// <summary>
	/// Description of frmVolumenEsfera.
	/// </summary>
	public partial class frmVolumenEsfera : Form
	{
		public frmVolumenEsfera()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
		void Button1Click(object sender, EventArgs e)
		{
		
    double radio;
    if (!double.TryParse(textBox1.Text, out radio) || radio <= 0)
    {
        MessageBox.Show("Ingrese un valor válido para el radio");
        return;
    }

    double volumen = (4.0 / 3.0) * Math.PI * radio * radio * radio;
    label1.Text = "Volumen de la esfera = " + volumen;

		}
	}
}
