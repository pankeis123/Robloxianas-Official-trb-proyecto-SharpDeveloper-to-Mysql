﻿/*
 * Creado por SharpDevelop.
 * Usuario: olive
 * Fecha: 12/14/2025
 * Hora: 4:45 PM
 * 
 * Para cambiar esta plantilla use Herramientas | Opciones | Codificación | Editar Encabezados Estándar
 */
using System;
using System.Drawing;
using System.Windows.Forms;

namespace GItYSharp
{
	/// <summary>
	/// Description of frmConvMasa.
	/// </summary>
	public partial class frmConvMasa : Form
	{
		public frmConvMasa()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
		void Button1Click(object sender, EventArgs e)
		{
		
    string[] datos = textBox1.Text.Split(',');
    if (datos.Length != 2)
    {
        MessageBox.Show("Formato: valor,unidad (ejemplo: 2,Kilogramos)");
        return;
    }

    double valor;
    if (!double.TryParse(datos[0], out valor) || valor < 0)
    {
        MessageBox.Show("Ingrese un número válido");
        return;
    }

    string unidad = datos[1].Trim();
    double resultado = valor;

    if (unidad == "Kilogramos")
        resultado = valor * 1000;
    else if (unidad == "Gramos")
        resultado = valor / 1000;
    else
        MessageBox.Show("Unidad no reconocida");

    label1.Text = "Resultado = " + resultado;
	
		}
	}
}
