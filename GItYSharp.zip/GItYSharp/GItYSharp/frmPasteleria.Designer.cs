﻿/*
 * Creado por SharpDevelop.
 * Usuario: olive
 * Fecha: 12/14/2025
 * Hora: 8:31 PM
 * 
 * Para cambiar esta plantilla use Herramientas | Opciones | Codificación | Editar Encabezados Estándar
 */
namespace GItYSharp
{
	partial class frmPasteleria
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			this.cboProducto = new System.Windows.Forms.ComboBox();
			this.rbDulce = new System.Windows.Forms.RadioButton();
			this.rbSalado = new System.Windows.Forms.RadioButton();
			this.txtPrecio = new System.Windows.Forms.TextBox();
			this.txtCantidad = new System.Windows.Forms.TextBox();
			this.btnAgregar = new System.Windows.Forms.Button();
			this.btnEliminar = new System.Windows.Forms.Button();
			this.lvVenta = new System.Windows.Forms.ListView();
			this.columnHeader1 = new System.Windows.Forms.ColumnHeader();
			this.columnHeader2 = new System.Windows.Forms.ColumnHeader();
			this.columnHeader3 = new System.Windows.Forms.ColumnHeader();
			this.columnHeader4 = new System.Windows.Forms.ColumnHeader();
			this.txtPagado = new System.Windows.Forms.TextBox();
			this.btnGuardar = new System.Windows.Forms.Button();
			this.btnImprimir = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.lblTotal = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.lblCambio = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// cboProducto
			// 
			this.cboProducto.FormattingEnabled = true;
			this.cboProducto.Location = new System.Drawing.Point(38, 74);
			this.cboProducto.Name = "cboProducto";
			this.cboProducto.Size = new System.Drawing.Size(121, 24);
			this.cboProducto.TabIndex = 0;
			// 
			// rbDulce
			// 
			this.rbDulce.Location = new System.Drawing.Point(53, 25);
			this.rbDulce.Name = "rbDulce";
			this.rbDulce.Size = new System.Drawing.Size(104, 24);
			this.rbDulce.TabIndex = 1;
			this.rbDulce.TabStop = true;
			this.rbDulce.Text = "Dulce";
			this.rbDulce.UseVisualStyleBackColor = true;
			// 
			// rbSalado
			// 
			this.rbSalado.Location = new System.Drawing.Point(163, 25);
			this.rbSalado.Name = "rbSalado";
			this.rbSalado.Size = new System.Drawing.Size(104, 24);
			this.rbSalado.TabIndex = 2;
			this.rbSalado.TabStop = true;
			this.rbSalado.Text = "Salado";
			this.rbSalado.UseVisualStyleBackColor = true;
			// 
			// txtPrecio
			// 
			this.txtPrecio.Location = new System.Drawing.Point(53, 136);
			this.txtPrecio.Name = "txtPrecio";
			this.txtPrecio.Size = new System.Drawing.Size(100, 22);
			this.txtPrecio.TabIndex = 3;
			// 
			// txtCantidad
			// 
			this.txtCantidad.Location = new System.Drawing.Point(218, 136);
			this.txtCantidad.Name = "txtCantidad";
			this.txtCantidad.Size = new System.Drawing.Size(100, 22);
			this.txtCantidad.TabIndex = 4;
			// 
			// btnAgregar
			// 
			this.btnAgregar.Location = new System.Drawing.Point(398, 211);
			this.btnAgregar.Name = "btnAgregar";
			this.btnAgregar.Size = new System.Drawing.Size(75, 38);
			this.btnAgregar.TabIndex = 6;
			this.btnAgregar.Text = "Agregar";
			this.btnAgregar.UseVisualStyleBackColor = true;
			// 
			// btnEliminar
			// 
			this.btnEliminar.Location = new System.Drawing.Point(482, 211);
			this.btnEliminar.Name = "btnEliminar";
			this.btnEliminar.Size = new System.Drawing.Size(75, 38);
			this.btnEliminar.TabIndex = 7;
			this.btnEliminar.Text = "Eliminar";
			this.btnEliminar.UseVisualStyleBackColor = true;
			// 
			// lvVenta
			// 
			this.lvVenta.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
									this.columnHeader1,
									this.columnHeader2,
									this.columnHeader3,
									this.columnHeader4});
			this.lvVenta.Location = new System.Drawing.Point(53, 269);
			this.lvVenta.Name = "lvVenta";
			this.lvVenta.Size = new System.Drawing.Size(504, 151);
			this.lvVenta.TabIndex = 8;
			this.lvVenta.UseCompatibleStateImageBehavior = false;
			this.lvVenta.View = System.Windows.Forms.View.Details;
			// 
			// columnHeader1
			// 
			this.columnHeader1.Text = "Producto";
			this.columnHeader1.Width = 166;
			// 
			// columnHeader2
			// 
			this.columnHeader2.Text = "Precio";
			// 
			// columnHeader3
			// 
			this.columnHeader3.Text = "Cantidad";
			// 
			// columnHeader4
			// 
			this.columnHeader4.Text = "Total";
			// 
			// txtPagado
			// 
			this.txtPagado.Location = new System.Drawing.Point(153, 459);
			this.txtPagado.Name = "txtPagado";
			this.txtPagado.Size = new System.Drawing.Size(100, 22);
			this.txtPagado.TabIndex = 12;
			// 
			// btnGuardar
			// 
			this.btnGuardar.Location = new System.Drawing.Point(575, 318);
			this.btnGuardar.Name = "btnGuardar";
			this.btnGuardar.Size = new System.Drawing.Size(75, 38);
			this.btnGuardar.TabIndex = 14;
			this.btnGuardar.Text = "Guardar";
			this.btnGuardar.UseVisualStyleBackColor = true;
			// 
			// btnImprimir
			// 
			this.btnImprimir.Location = new System.Drawing.Point(575, 362);
			this.btnImprimir.Name = "btnImprimir";
			this.btnImprimir.Size = new System.Drawing.Size(75, 38);
			this.btnImprimir.TabIndex = 15;
			this.btnImprimir.Text = "Imprimir";
			this.btnImprimir.UseVisualStyleBackColor = true;
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(53, 161);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(100, 23);
			this.label1.TabIndex = 16;
			this.label1.Text = "Precio";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(218, 161);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(100, 23);
			this.label2.TabIndex = 17;
			this.label2.Text = "Cantidad";
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(57, 431);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(100, 23);
			this.label3.TabIndex = 18;
			this.label3.Text = "Total";
			// 
			// lblTotal
			// 
			this.lblTotal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
			this.lblTotal.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblTotal.Location = new System.Drawing.Point(153, 430);
			this.lblTotal.Name = "lblTotal";
			this.lblTotal.Size = new System.Drawing.Size(100, 23);
			this.lblTotal.TabIndex = 19;
			// 
			// label5
			// 
			this.label5.Location = new System.Drawing.Point(259, 444);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(100, 23);
			this.label5.TabIndex = 21;
			this.label5.Text = "Cambio";
			// 
			// label6
			// 
			this.label6.Location = new System.Drawing.Point(57, 460);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(100, 23);
			this.label6.TabIndex = 22;
			this.label6.Text = "Pagado";
			// 
			// lblCambio
			// 
			this.lblCambio.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
			this.lblCambio.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblCambio.Location = new System.Drawing.Point(344, 445);
			this.lblCambio.Name = "lblCambio";
			this.lblCambio.Size = new System.Drawing.Size(100, 23);
			this.lblCambio.TabIndex = 25;
			// 
			// frmPasteleria
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(670, 504);
			this.Controls.Add(this.lblCambio);
			this.Controls.Add(this.label6);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.lblTotal);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.btnImprimir);
			this.Controls.Add(this.btnGuardar);
			this.Controls.Add(this.txtPagado);
			this.Controls.Add(this.lvVenta);
			this.Controls.Add(this.btnEliminar);
			this.Controls.Add(this.btnAgregar);
			this.Controls.Add(this.txtCantidad);
			this.Controls.Add(this.txtPrecio);
			this.Controls.Add(this.rbSalado);
			this.Controls.Add(this.rbDulce);
			this.Controls.Add(this.cboProducto);
			this.Name = "frmPasteleria";
			this.Text = "frmPasteleria";
			this.ResumeLayout(false);
			this.PerformLayout();
		}
		private System.Windows.Forms.Label lblCambio;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label lblTotal;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Button btnImprimir;
		private System.Windows.Forms.Button btnGuardar;
		private System.Windows.Forms.TextBox txtPagado;
		private System.Windows.Forms.ColumnHeader columnHeader4;
		private System.Windows.Forms.ColumnHeader columnHeader3;
		private System.Windows.Forms.ColumnHeader columnHeader2;
		private System.Windows.Forms.ColumnHeader columnHeader1;
		private System.Windows.Forms.ListView lvVenta;
		private System.Windows.Forms.Button btnEliminar;
		private System.Windows.Forms.Button btnAgregar;
		private System.Windows.Forms.TextBox txtCantidad;
		private System.Windows.Forms.TextBox txtPrecio;
		private System.Windows.Forms.RadioButton rbSalado;
		private System.Windows.Forms.RadioButton rbDulce;
		private System.Windows.Forms.ComboBox cboProducto;
	}
}
