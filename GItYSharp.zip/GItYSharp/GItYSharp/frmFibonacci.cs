﻿using System;
using System.Windows.Forms;

namespace GItYSharp
{
    public partial class frmFibonacci : Form
    {
        public frmFibonacci()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            int n;
            if (!int.TryParse(txtNumero.Text, out n) || n <= 0)
            {
                MessageBox.Show("Ingrese un número entero positivo");
                return;
            }

            lblResultado.Text = ""; // limpiar antes de mostrar

            int a = 0, b = 1;
            lblResultado.Text += a + " ";
            if (n > 1) lblResultado.Text += b + " ";

            for (int i = 2; i < n; i++)
            {
                int c = a + b;
                lblResultado.Text += c + " ";
                a = b;
                b = c;
            }
        }
    }
}