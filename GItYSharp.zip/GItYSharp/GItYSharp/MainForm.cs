﻿/*
 * Creado por SharpDevelop.
 * Usuario: olive
 * Fecha: 11/28/2025
 * Hora: 6:31 PM
 * 
 * Para cambiar esta plantilla use Herramientas | Opciones | Codificación | Editar Encabezados Estándar
 */
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace GItYSharp
{
	/// <summary>
	/// Description of MainForm.
	/// </summary>
	public partial class MainForm : Form
	{
		// Variable para contar intentos
		private int intentos = 0;
		private const int maxIntentos = 3;
		
		public MainForm()
		{
			InitializeComponent();
		}
		
		void Button1Click(object sender, EventArgs e)
		{
			string usuarioCorrecto = "Robloxianas";
			string contrasenaCorrecta = "1234567890";
			
			if (txtUsario.Text == usuarioCorrecto && txtContraseña.Text == contrasenaCorrecta)
			{
				MessageBox.Show("Acceso concedido Añacedido proceseda PEpe", 
				                "Login", MessageBoxButtons.OK, MessageBoxIcon.Information);
				
				frmPrincipal menu = new frmPrincipal();
				menu.Show();
				this.Hide();
			}
			else
			{
				intentos++;
				if (intentos >= maxIntentos)
				{
					MessageBox.Show("Has excedido el número máximo de intentos. El programa se cerrará.", 
					                "Login", MessageBoxButtons.OK, MessageBoxIcon.Stop);
					Application.Exit();
				}
				else
				{
					MessageBox.Show("Usuario o contraseña incorrectos 🙀\nIntento " + intentos + " de " + maxIntentos, 
					                "Login", MessageBoxButtons.OK, MessageBoxIcon.Error);
				}
			}
		}
	}
}