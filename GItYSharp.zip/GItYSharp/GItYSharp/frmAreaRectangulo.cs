﻿/*
 * Creado por SharpDevelop.
 * Usuario: olive
 * Fecha: 12/14/2025
 * Hora: 4:35 PM
 * 
 * Para cambiar esta plantilla use Herramientas | Opciones | Codificación | Editar Encabezados Estándar
 */
using System;
using System.Drawing;
using System.Windows.Forms;

namespace GItYSharp
{
	/// <summary>
	/// Description of frmAreaRectangulo.
	/// </summary>
	public partial class frmAreaRectangulo : Form
	{
		public frmAreaRectangulo()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
		void Button1Click(object sender, EventArgs e)
		{
		
    string[] valores = textBox1.Text.Split(',');
    if (valores.Length != 2)
    {
        MessageBox.Show("Ingrese base y altura separados por coma (ejemplo: 5,3)");
        return;
    }

    double b, h;
    if (!double.TryParse(valores[0], out b) || !double.TryParse(valores[1], out h) || b <= 0 || h <= 0)
    {
        MessageBox.Show("Valores inválidos");
        return;
    }

    double area = b * h;
    double perimetro = 2 * (b + h);

    label1.Text = "Área = " + area + " | Perímetro = " + perimetro;

		}
	}
}
