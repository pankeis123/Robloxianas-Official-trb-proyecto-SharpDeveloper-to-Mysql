﻿/*
 * Creado por SharpDevelop.
 * Usuario: olive
 * Fecha: 12/14/2025
 * Hora: 4:37 PM
 * 
 * Para cambiar esta plantilla use Herramientas | Opciones | Codificación | Editar Encabezados Estándar
 */
using System;
using System.Drawing;
using System.Windows.Forms;

namespace GItYSharp
{
	/// <summary>
	/// Description of frmPerimetroCircunferencia.
	/// </summary>
	public partial class frmPerimetroCircunferencia : Form
	{
		public frmPerimetroCircunferencia()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
		void Button1Click(object sender, EventArgs e)
		
			
{
    double radio;
    if (!double.TryParse(textBox1.Text, out radio) || radio <= 0)
    {
        MessageBox.Show("Ingrese un valor válido para el radio");
        return;
    }

    double perimetro = 2 * Math.PI * radio;
    label1.Text = "Perímetro de la circunferencia = " + perimetro;

		}
	}
}
