﻿/*
 * Creado por SharpDevelop.
 * Usuario: olive
 * Fecha: 12/14/2025
 * Hora: 4:49 PM
 * 
 * Para cambiar esta plantilla use Herramientas | Opciones | Codificación | Editar Encabezados Estándar
 */
using System;
using System.Drawing;
using System.Windows.Forms;

namespace GItYSharp
{
	/// <summary>
	/// Description of frmAcercaDe.
	/// </summary>
	public partial class frmAcercaDe : Form
	{
		public frmAcercaDe()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
		void FrmAcercaDeLoad(object sender, EventArgs e)
		{
			
		}
		
		void Button1Click(object sender, EventArgs e)
		{


    this.Close();

		}
	}
}
