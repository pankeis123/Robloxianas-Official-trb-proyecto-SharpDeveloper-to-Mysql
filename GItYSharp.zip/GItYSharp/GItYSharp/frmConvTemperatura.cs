﻿/*
 * Creado por SharpDevelop.
 * Usuario: olive
 * Fecha: 12/14/2025
 * Hora: 4:45 PM
 * 
 * Para cambiar esta plantilla use Herramientas | Opciones | Codificación | Editar Encabezados Estándar
 */
using System;
using System.Drawing;
using System.Windows.Forms;

namespace GItYSharp
{
	/// <summary>
	/// Description of frmConvTemperatura.
	/// </summary>
	public partial class frmConvTemperatura : Form
	{
		public frmConvTemperatura()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
		void Button1Click(object sender, EventArgs e)
		{

    string[] datos = textBox1.Text.Split(',');
    if (datos.Length != 2)
    {
        MessageBox.Show("Formato: valor,unidad (ejemplo: 100,Celsius)");
        return;
    }

    double valor;
    if (!double.TryParse(datos[0], out valor))
    {
        MessageBox.Show("Ingrese un número válido");
        return;
    }

    string unidad = datos[1].Trim();
    double resultado = valor;

    if (unidad == "Celsius")
        resultado = (valor * 9 / 5) + 32;
    else if (unidad == "Fahrenheit")
        resultado = (valor - 32) * 5 / 9;
    else
        MessageBox.Show("Unidad no reconocida");

    label1.Text = "Resultado = " + resultado;

		}
	}
}
