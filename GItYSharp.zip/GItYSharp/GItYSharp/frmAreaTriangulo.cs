﻿/*
 * Creado por SharpDevelop.
 * Usuario: olive
 * Fecha: 12/14/2025
 * Hora: 4:35 PM
 * 
 * Para cambiar esta plantilla use Herramientas | Opciones | Codificación | Editar Encabezados Estándar
 */
using System;
using System.Drawing;
using System.Windows.Forms;

namespace GItYSharp
{
	/// <summary>
	/// Description of frmAreaTriangulo.
	/// </summary>
	public partial class frmAreaTriangulo : Form
	{
		public frmAreaTriangulo()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
		void Button1Click(object sender, EventArgs e)
		{

    string[] valores = textBox1.Text.Split(',');
    if (valores.Length != 3)
    {
        MessageBox.Show("Ingrese base, altura y otro lado separados por coma (ejemplo: 4,3,5)");
        return;
    }

    double b, h, l;
    if (!double.TryParse(valores[0], out b) || 
        !double.TryParse(valores[1], out h) || 
        !double.TryParse(valores[2], out l) || 
        b <= 0 || h <= 0 || l <= 0)
    {
        MessageBox.Show("Valores inválidos");
        return;
    }

    double area = (b * h) / 2;
    double perimetro = b + h + l;

    label1.Text = "Área = " + area + " | Perímetro = " + perimetro;

		}
	}
}
