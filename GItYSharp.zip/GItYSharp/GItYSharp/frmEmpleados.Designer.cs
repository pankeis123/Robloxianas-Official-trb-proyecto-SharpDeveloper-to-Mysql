﻿/*
 * Creado por SharpDevelop.
 * Usuario: olive
 * Fecha: 12/14/2025
 * Hora: 5:03 PM
 * 
 * Para cambiar esta plantilla use Herramientas | Opciones | Codificación | Editar Encabezados Estándar
 */
namespace GItYSharp
{
	partial class frmEmpleados
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.txtNombre = new System.Windows.Forms.TextBox();
			this.txtSueldo = new System.Windows.Forms.TextBox();
			this.txtPuesto = new System.Windows.Forms.TextBox();
			this.dtpIngreso = new System.Windows.Forms.DateTimePicker();
			this.cboTurno = new System.Windows.Forms.ComboBox();
			this.btnGuardar = new System.Windows.Forms.Button();
			this.btnEliminar = new System.Windows.Forms.Button();
			this.Limpiar = new System.Windows.Forms.Button();
			this.dgvEmpleados = new System.Windows.Forms.DataGridView();
			this.epValidacion = new System.Windows.Forms.ErrorProvider(this.components);
			this.btnActualizar = new System.Windows.Forms.Button();
			this.btnBuscar = new System.Windows.Forms.Button();
			this.txtBuscar = new System.Windows.Forms.TextBox();
			((System.ComponentModel.ISupportInitialize)(this.dgvEmpleados)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.epValidacion)).BeginInit();
			this.SuspendLayout();
			// 
			// txtNombre
			// 
			this.txtNombre.Location = new System.Drawing.Point(34, 63);
			this.txtNombre.Name = "txtNombre";
			this.txtNombre.Size = new System.Drawing.Size(166, 22);
			this.txtNombre.TabIndex = 0;
			// 
			// txtSueldo
			// 
			this.txtSueldo.Location = new System.Drawing.Point(336, 63);
			this.txtSueldo.Name = "txtSueldo";
			this.txtSueldo.Size = new System.Drawing.Size(100, 22);
			this.txtSueldo.TabIndex = 2;
			// 
			// txtPuesto
			// 
			this.txtPuesto.Location = new System.Drawing.Point(217, 63);
			this.txtPuesto.Name = "txtPuesto";
			this.txtPuesto.Size = new System.Drawing.Size(100, 22);
			this.txtPuesto.TabIndex = 3;
			// 
			// dtpIngreso
			// 
			this.dtpIngreso.Location = new System.Drawing.Point(34, 116);
			this.dtpIngreso.Name = "dtpIngreso";
			this.dtpIngreso.Size = new System.Drawing.Size(228, 22);
			this.dtpIngreso.TabIndex = 4;
			// 
			// cboTurno
			// 
			this.cboTurno.FormattingEnabled = true;
			this.cboTurno.Location = new System.Drawing.Point(285, 114);
			this.cboTurno.Name = "cboTurno";
			this.cboTurno.Size = new System.Drawing.Size(121, 24);
			this.cboTurno.TabIndex = 5;
			// 
			// btnGuardar
			// 
			this.btnGuardar.Location = new System.Drawing.Point(488, 63);
			this.btnGuardar.Name = "btnGuardar";
			this.btnGuardar.Size = new System.Drawing.Size(75, 23);
			this.btnGuardar.TabIndex = 6;
			this.btnGuardar.Text = "Guardar";
			this.btnGuardar.UseVisualStyleBackColor = true;
			// 
			// btnEliminar
			// 
			this.btnEliminar.Location = new System.Drawing.Point(488, 92);
			this.btnEliminar.Name = "btnEliminar";
			this.btnEliminar.Size = new System.Drawing.Size(75, 23);
			this.btnEliminar.TabIndex = 7;
			this.btnEliminar.Text = "Eliminar";
			this.btnEliminar.UseVisualStyleBackColor = true;
			// 
			// Limpiar
			// 
			this.Limpiar.Location = new System.Drawing.Point(488, 121);
			this.Limpiar.Name = "Limpiar";
			this.Limpiar.Size = new System.Drawing.Size(75, 23);
			this.Limpiar.TabIndex = 8;
			this.Limpiar.Text = "Limpiar";
			this.Limpiar.UseVisualStyleBackColor = true;
			// 
			// dgvEmpleados
			// 
			this.dgvEmpleados.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dgvEmpleados.Location = new System.Drawing.Point(106, 204);
			this.dgvEmpleados.Name = "dgvEmpleados";
			this.dgvEmpleados.RowTemplate.Height = 24;
			this.dgvEmpleados.Size = new System.Drawing.Size(665, 150);
			this.dgvEmpleados.TabIndex = 9;
			// 
			// epValidacion
			// 
			this.epValidacion.ContainerControl = this;
			// 
			// btnActualizar
			// 
			this.btnActualizar.Location = new System.Drawing.Point(579, 63);
			this.btnActualizar.Name = "btnActualizar";
			this.btnActualizar.Size = new System.Drawing.Size(94, 23);
			this.btnActualizar.TabIndex = 10;
			this.btnActualizar.Text = "Actualizar";
			this.btnActualizar.UseVisualStyleBackColor = true;
			this.btnActualizar.Click += new System.EventHandler(this.BtnActualizarClick);
			// 
			// btnBuscar
			// 
			this.btnBuscar.Location = new System.Drawing.Point(798, 244);
			this.btnBuscar.Name = "btnBuscar";
			this.btnBuscar.Size = new System.Drawing.Size(75, 23);
			this.btnBuscar.TabIndex = 11;
			this.btnBuscar.Text = "Buscar";
			this.btnBuscar.UseVisualStyleBackColor = true;
			// 
			// txtBuscar
			// 
			this.txtBuscar.Location = new System.Drawing.Point(789, 216);
			this.txtBuscar.Name = "txtBuscar";
			this.txtBuscar.Size = new System.Drawing.Size(100, 22);
			this.txtBuscar.TabIndex = 13;
			// 
			// frmEmpleados
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(901, 469);
			this.Controls.Add(this.txtBuscar);
			this.Controls.Add(this.btnBuscar);
			this.Controls.Add(this.btnActualizar);
			this.Controls.Add(this.dgvEmpleados);
			this.Controls.Add(this.Limpiar);
			this.Controls.Add(this.btnEliminar);
			this.Controls.Add(this.btnGuardar);
			this.Controls.Add(this.cboTurno);
			this.Controls.Add(this.dtpIngreso);
			this.Controls.Add(this.txtPuesto);
			this.Controls.Add(this.txtSueldo);
			this.Controls.Add(this.txtNombre);
			this.Name = "frmEmpleados";
			this.Text = "frmEmpleados";
			((System.ComponentModel.ISupportInitialize)(this.dgvEmpleados)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.epValidacion)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();
		}
		private System.Windows.Forms.TextBox txtBuscar;
		private System.Windows.Forms.Button btnBuscar;
		private System.Windows.Forms.Button btnActualizar;
		private System.Windows.Forms.ErrorProvider epValidacion;
		private System.Windows.Forms.DataGridView dgvEmpleados;
		private System.Windows.Forms.Button Limpiar;
		private System.Windows.Forms.Button btnEliminar;
		private System.Windows.Forms.Button btnGuardar;
		private System.Windows.Forms.ComboBox cboTurno;
		private System.Windows.Forms.DateTimePicker dtpIngreso;
		private System.Windows.Forms.TextBox txtPuesto;
		private System.Windows.Forms.TextBox txtSueldo;
		private System.Windows.Forms.TextBox txtNombre;
		
		void BtnActualizarClick(object sender, System.EventArgs e)
		{
			
		}
	}
}
