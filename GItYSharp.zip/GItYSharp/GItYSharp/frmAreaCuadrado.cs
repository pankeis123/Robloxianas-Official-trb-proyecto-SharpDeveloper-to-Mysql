﻿/*
 * Creado por SharpDevelop.
 * Usuario: olive
 * Fecha: 12/14/2025
 * Hora: 4:32 PM
 * 
 * Para cambiar esta plantilla use Herramientas | Opciones | Codificación | Editar Encabezados Estándar
 */
using System;
using System.Drawing;
using System.Windows.Forms;

namespace GItYSharp
{
	/// <summary>
	/// Description of frmAreaCuadrado.
	/// </summary>
	public partial class frmAreaCuadrado : Form
	{
		public frmAreaCuadrado()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
		void Label1Click(object sender, EventArgs e)
		{
		
    double lado;
    if (!double.TryParse(textBox1.Text, out lado) || lado <= 0)
    {
        MessageBox.Show("Ingrese un valor válido para el lado");
        return;
    }

    double area = lado * lado;
    double perimetro = 4 * lado;

    label1.Text = "Área = " + area + " | Perímetro = " + perimetro;

		}
	}
}
