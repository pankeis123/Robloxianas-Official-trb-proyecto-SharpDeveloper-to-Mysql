﻿/*
 * Creado por SharpDevelop.
 * Usuario: olive
 * Fecha: 12/14/2025
 * Hora: 4:38 PM
 * 
 * Para cambiar esta plantilla use Herramientas | Opciones | Codificación | Editar Encabezados Estándar
 */
using System;
using System.Drawing;
using System.Windows.Forms;

namespace GItYSharp
{
	/// <summary>
	/// Description of frmPerimetroTrapecio.
	/// </summary>
	public partial class frmPerimetroTrapecio : Form
	{
		public frmPerimetroTrapecio()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
		void Button1Click(object sender, EventArgs e)
		{
		
    string[] lados = textBox1.Text.Split(',');
    if (lados.Length != 4)
    {
        MessageBox.Show("Formato: lado1,lado2,lado3,lado4");
        return;
    }

    double l1, l2, l3, l4;
    if (!double.TryParse(lados[0], out l1) || !double.TryParse(lados[1], out l2) ||
        !double.TryParse(lados[2], out l3) || !double.TryParse(lados[3], out l4) ||
        l1 <= 0 || l2 <= 0 || l3 <= 0 || l4 <= 0)
    {
        MessageBox.Show("Valores inválidos");
        return;
    }

    double perimetro = l1 + l2 + l3 + l4;
    label1.Text = "Perímetro del trapecio = " + perimetro;

		}
	}
}
