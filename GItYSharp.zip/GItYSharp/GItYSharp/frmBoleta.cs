﻿/*
 * Creado por SharpDevelop.
 * Usuario: xodix
 * Fecha: 14/12/2025
 * Hora: 9:04 PM
 */
using System;
using System.Drawing;
using System.Windows.Forms;

namespace GItYSharp
{
    public partial class frmBoleta : Form
    {
        public frmBoleta()
        {
            InitializeComponent();
        }

        // Botón Agregar
        private void btnAgregar_Click(object sender, EventArgs e)
        {
            string materia = txtMateria.Text.Trim();
            decimal p1, p2, p3;

            if (materia == "")
            {
                MessageBox.Show("Ingrese el nombre de la materia");
                return;
            }

            if (!decimal.TryParse(txtP1.Text, out p1) ||
                !decimal.TryParse(txtP2.Text, out p2) ||
                !decimal.TryParse(txtP3.Text, out p3))
            {
                MessageBox.Show("Ingrese calificaciones válidas en los tres parciales");
                return;
            }

            decimal promedio = Math.Round((p1 + p2 + p3) / 3m, 2);

            ListViewItem item = new ListViewItem(materia);
            item.SubItems.Add(p1.ToString("0.00"));
            item.SubItems.Add(p2.ToString("0.00"));
            item.SubItems.Add(p3.ToString("0.00"));
            item.SubItems.Add(promedio.ToString("0.00"));
            lvBoleta.Items.Add(item);

            LimpiarCampos();
        }

        // Botón Eliminar
        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (lvBoleta.SelectedItems.Count == 0)
            {
                MessageBox.Show("Seleccione una fila para eliminar");
                return;
            }

            lvBoleta.Items.Remove(lvBoleta.SelectedItems[0]);
        }

        // Limpiar campos
        private void LimpiarCampos()
        {
            txtMateria.Text = "";
            txtP1.Text = "";
            txtP2.Text = "";
            txtP3.Text = "";
            txtMateria.Focus();
        }

        // Evento opcional para mostrar promedio general
        private void btnPromedioGeneral_Click(object sender, EventArgs e)
        {
            if (lvBoleta.Items.Count == 0)
            {
                MessageBox.Show("No hay materias registradas");
                return;
            }

            decimal suma = 0;
            foreach (ListViewItem item in lvBoleta.Items)
            {
                suma += decimal.Parse(item.SubItems[4].Text);
            }

            decimal promedioGeneral = Math.Round(suma / lvBoleta.Items.Count, 2);
            MessageBox.Show("Promedio general: " + promedioGeneral.ToString("0.00"));
        }
    }
}