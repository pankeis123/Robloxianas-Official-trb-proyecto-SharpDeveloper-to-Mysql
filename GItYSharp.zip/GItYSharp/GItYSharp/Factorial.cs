﻿using System;
using System.Windows.Forms;

namespace GItYSharp
{
    public partial class frmFactorial : Form
    {
        public frmFactorial()
        {
            InitializeComponent();
        }

        private void BtnCalcularClick(object sender, EventArgs e)
        {
            int n;
            if (!int.TryParse(txtNumero.Text, out n) || n < 0)
            {
                MessageBox.Show("Ingrese un número entero positivo");
                return;
            }

            long factorial = 1;
            for (int i = 1; i <= n; i++)
            {
                factorial *= i;
            }

            lblResultado.Text = "Factorial de " + n + " = " + factorial;
        }
    }
}