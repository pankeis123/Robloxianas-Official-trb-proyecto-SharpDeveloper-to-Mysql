﻿/*
 * Creado por SharpDevelop.
 * Usuario: olive
 * Fecha: 11/28/2025
 * Hora: 6:42 PM
 * 
 * Para cambiar esta plantilla use Herramientas | Opciones | Codificación | Editar Encabezados Estándar
 */
using System;
using System.Drawing;
using System.Windows.Forms;

namespace GItYSharp
{
	/// <summary>
	/// Description of Menu.
	/// </summary>
	public partial class frmMenu : Form
	{
		public frmMenu()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
	}
}
