﻿using System;
using System.Data;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace GItYSharp
{
    public partial class frmEmpleados : Form
    {
        // 🔧 Conexión corregida: sin "SslMode=none"
        private string connectionString = "Server=localhost;Database=sistema_tienda;Uid=root;Pwd=root09218743;";
        private int empleadoIdSeleccionado = 0;

        public frmEmpleados()
        {
            InitializeComponent();
            ConfigurarControles();
            CargarTurnos();
            CargarEmpleados();
        }

        private void ConfigurarControles()
        {
            dgvEmpleados.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvEmpleados.MultiSelect = false;
            dgvEmpleados.ReadOnly = true;
            dgvEmpleados.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvEmpleados.AllowUserToAddRows = false;

            dtpIngreso.Format = DateTimePickerFormat.Short;

            dgvEmpleados.CellClick += dgvEmpleados_CellClick;
            btnGuardar.Click += btnGuardar_Click;
            btnEliminar.Click += btnEliminar_Click;
            btnActualizar.Click += btnActualizar_Click;
            btnBuscar.Click += btnBuscar_Click;
            Limpiar.Click += Limpiar_Click;
        }

        private void CargarTurnos()
        {
            cboTurno.Items.Clear();
            cboTurno.Items.Add("Matutino");
            cboTurno.Items.Add("Vespertino");
            cboTurno.Items.Add("Nocturno");
            if (cboTurno.Items.Count > 0) cboTurno.SelectedIndex = 0;
        }

        private bool ValidarEntrada()
        {
            bool ok = true;
            epValidacion.Clear();

            if (string.IsNullOrWhiteSpace(txtNombre.Text))
            {
                epValidacion.SetError(txtNombre, "Nombre requerido");
                ok = false;
            }
            if (string.IsNullOrWhiteSpace(txtPuesto.Text))
            {
                epValidacion.SetError(txtPuesto, "Puesto requerido");
                ok = false;
            }
            decimal sueldo;
            if (!decimal.TryParse(txtSueldo.Text, out sueldo) || sueldo <= 0)
            {
                epValidacion.SetError(txtSueldo, "Sueldo válido > 0");
                ok = false;
            }
            if (cboTurno.SelectedItem == null)
            {
                epValidacion.SetError(cboTurno, "Seleccione turno");
                ok = false;
            }

            return ok;
        }

        private void CargarEmpleados()
        {
            try
            {
                using (MySqlConnection cn = new MySqlConnection(connectionString))
                {
                    cn.Open();
                    using (MySqlDataAdapter da = new MySqlDataAdapter(
                        "SELECT id, nombre, puesto, sueldo, fecha_ingreso, turno FROM empleados ORDER BY id DESC", cn))
                    {
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        dgvEmpleados.DataSource = dt;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar: " + ex.Message);
            }
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            if (!ValidarEntrada()) return;

            try
            {
                using (MySqlConnection cn = new MySqlConnection(connectionString))
                {
                    cn.Open();
                    using (MySqlCommand cmd = new MySqlCommand(
                        "INSERT INTO empleados (nombre, puesto, sueldo, fecha_ingreso, turno) VALUES (@n,@p,@s,@f,@t)", cn))
                    {
                        cmd.Parameters.AddWithValue("@n", txtNombre.Text.Trim());
                        cmd.Parameters.AddWithValue("@p", txtPuesto.Text.Trim());
                        cmd.Parameters.AddWithValue("@s", Decimal.Parse(txtSueldo.Text.Trim()));
                        cmd.Parameters.AddWithValue("@f", dtpIngreso.Value.ToString("yyyy-MM-dd"));
                        cmd.Parameters.AddWithValue("@t", cboTurno.SelectedItem.ToString());
                        cmd.ExecuteNonQuery();
                    }
                }
                LimpiarCampos();
                CargarEmpleados();
                MessageBox.Show("Empleado guardado correctamente");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al guardar: " + ex.Message);
            }
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (empleadoIdSeleccionado == 0)
            {
                MessageBox.Show("Seleccione un empleado en la tabla");
                return;
            }

            var r = MessageBox.Show("¿Desea eliminar el empleado seleccionado?", "Confirmar", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (r != DialogResult.Yes) return;

            try
            {
                using (MySqlConnection cn = new MySqlConnection(connectionString))
                {
                    cn.Open();
                    using (MySqlCommand cmd = new MySqlCommand("DELETE FROM empleados WHERE id=@id", cn))
                    {
                        cmd.Parameters.AddWithValue("@id", empleadoIdSeleccionado);
                        cmd.ExecuteNonQuery();
                    }
                }
                LimpiarCampos();
                CargarEmpleados();
                MessageBox.Show("Empleado eliminado correctamente");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al eliminar: " + ex.Message);
            }
        }

        private void btnActualizar_Click(object sender, EventArgs e)
        {
            if (empleadoIdSeleccionado == 0)
            {
                MessageBox.Show("Seleccione un empleado en la tabla");
                return;
            }
            if (!ValidarEntrada()) return;

            try
            {
                using (MySqlConnection cn = new MySqlConnection(connectionString))
                {
                    cn.Open();
                    using (MySqlCommand cmd = new MySqlCommand(
                        "UPDATE empleados SET nombre=@n, puesto=@p, sueldo=@s, fecha_ingreso=@f, turno=@t WHERE id=@id", cn))
                    {
                        cmd.Parameters.AddWithValue("@n", txtNombre.Text.Trim());
                        cmd.Parameters.AddWithValue("@p", txtPuesto.Text.Trim());
                        cmd.Parameters.AddWithValue("@s", Decimal.Parse(txtSueldo.Text.Trim()));
                        cmd.Parameters.AddWithValue("@f", dtpIngreso.Value.ToString("yyyy-MM-dd"));
                        cmd.Parameters.AddWithValue("@t", cboTurno.SelectedItem.ToString());
                        cmd.Parameters.AddWithValue("@id", empleadoIdSeleccionado);
                        cmd.ExecuteNonQuery();
                    }
                }
                CargarEmpleados();
                MessageBox.Show("Empleado actualizado correctamente");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al actualizar: " + ex.Message);
            }
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            string q = txtBuscar.Text.Trim();
            if (q == "")
            {
                CargarEmpleados();
                return;
            }

            try
            {
                using (MySqlConnection cn = new MySqlConnection(connectionString))
                {
                    cn.Open();
                    using (MySqlDataAdapter da = new MySqlDataAdapter(
                        "SELECT id, nombre, puesto, sueldo, fecha_ingreso, turno FROM empleados " +
                        "WHERE nombre LIKE @q OR puesto LIKE @q ORDER BY id DESC", cn))
                    {
                        da.SelectCommand.Parameters.AddWithValue("@q", "%" + q + "%");
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        dgvEmpleados.DataSource = dt;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al buscar: " + ex.Message);
            }
        }

        private void dgvEmpleados_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0 || dgvEmpleados.CurrentRow == null) return;

            DataGridViewRow row = dgvEmpleados.CurrentRow;
            empleadoIdSeleccionado = Convert.ToInt32(row.Cells["id"].Value);
            txtNombre.Text = Convert.ToString(row.Cells["nombre"].Value);
            txtPuesto.Text = Convert.ToString(row.Cells["puesto"].Value);
            txtSueldo.Text = Convert.ToDecimal(row.Cells["sueldo"].Value).ToString("0.00");

            DateTime fi;
            if (DateTime.TryParse(Convert.ToString(row.Cells["fecha_ingreso"].Value), out fi))
                dtpIngreso.Value = fi;

            string turno = Convert.ToString(row.Cells["turno"].Value);
            int idx = cboTurno.Items.IndexOf(turno);
            if (idx >= 0) cboTurno.SelectedIndex = idx;
        }

        private void Limpiar_Click(object sender, EventArgs e)
        {
            LimpiarCampos();
        }

        private void LimpiarCampos()
        {
            empleadoIdSeleccionado = 0;
            txtNombre.Clear();
            txtPuesto.Clear();
            txtSueldo.Clear();
            txtBuscar.Clear();
            if (cboTurno.Items.Count > 0) cboTurno.SelectedIndex = 0;
            dtpIngreso.Value = DateTime.Today;
            epValidacion.Clear();
            dgvEmpleados.ClearSelection();
        }
    }
}