﻿/*
 * Creado por SharpDevelop.
 * Usuario: olive
 * Fecha: 12/14/2025
 * Hora: 4:05 PM
 * 
 * Para cambiar esta plantilla use Herramientas | Opciones | Codificación | Editar Encabezados Estándar
 */
namespace GItYSharp
{
	partial class frmPrincipal
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			this.menuStrip1 = new System.Windows.Forms.MenuStrip();
			this.aplicacionesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.factorialToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.finnabociToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.areaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.cuadradoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.rectanguloToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.trianguloToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.perimetroToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.circurferenciaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.trapecioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.volumenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.esferaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.cuboToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.piramideToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.conversionesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.longitudKmAMIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.masaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.temperaturaCAFToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.tiempoSegAHorasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.boletaDeCalificacionesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.pasteleriaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.empleadosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.archivoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.salirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.acercaDeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.menuStrip1.SuspendLayout();
			this.SuspendLayout();
			// 
			// menuStrip1
			// 
			this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
									this.aplicacionesToolStripMenuItem,
									this.areaToolStripMenuItem,
									this.perimetroToolStripMenuItem,
									this.volumenToolStripMenuItem,
									this.conversionesToolStripMenuItem,
									this.boletaDeCalificacionesToolStripMenuItem,
									this.pasteleriaToolStripMenuItem,
									this.empleadosToolStripMenuItem,
									this.archivoToolStripMenuItem,
									this.acercaDeToolStripMenuItem});
			this.menuStrip1.Location = new System.Drawing.Point(0, 0);
			this.menuStrip1.Name = "menuStrip1";
			this.menuStrip1.Size = new System.Drawing.Size(1035, 28);
			this.menuStrip1.TabIndex = 1;
			this.menuStrip1.Text = "menuStrip1";
			// 
			// aplicacionesToolStripMenuItem
			// 
			this.aplicacionesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
									this.factorialToolStripMenuItem,
									this.finnabociToolStripMenuItem});
			this.aplicacionesToolStripMenuItem.Name = "aplicacionesToolStripMenuItem";
			this.aplicacionesToolStripMenuItem.Size = new System.Drawing.Size(105, 24);
			this.aplicacionesToolStripMenuItem.Text = "Aplicaciones";
			// 
			// factorialToolStripMenuItem
			// 
			this.factorialToolStripMenuItem.Name = "factorialToolStripMenuItem";
			this.factorialToolStripMenuItem.Size = new System.Drawing.Size(141, 24);
			this.factorialToolStripMenuItem.Text = "Factorial";
			this.factorialToolStripMenuItem.Click += new System.EventHandler(this.FactorialToolStripMenuItemClick);
			// 
			// finnabociToolStripMenuItem
			// 
			this.finnabociToolStripMenuItem.Name = "finnabociToolStripMenuItem";
			this.finnabociToolStripMenuItem.Size = new System.Drawing.Size(141, 24);
			this.finnabociToolStripMenuItem.Text = "Fibonacci";
			this.finnabociToolStripMenuItem.Click += new System.EventHandler(this.FinnabociToolStripMenuItemClick);
			// 
			// areaToolStripMenuItem
			// 
			this.areaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
									this.cuadradoToolStripMenuItem,
									this.rectanguloToolStripMenuItem,
									this.trianguloToolStripMenuItem});
			this.areaToolStripMenuItem.Name = "areaToolStripMenuItem";
			this.areaToolStripMenuItem.Size = new System.Drawing.Size(52, 24);
			this.areaToolStripMenuItem.Text = "Area";
			// 
			// cuadradoToolStripMenuItem
			// 
			this.cuadradoToolStripMenuItem.Name = "cuadradoToolStripMenuItem";
			this.cuadradoToolStripMenuItem.Size = new System.Drawing.Size(153, 24);
			this.cuadradoToolStripMenuItem.Text = "Cuadrado";
			this.cuadradoToolStripMenuItem.Click += new System.EventHandler(this.CuadradoToolStripMenuItemClick);
			// 
			// rectanguloToolStripMenuItem
			// 
			this.rectanguloToolStripMenuItem.Name = "rectanguloToolStripMenuItem";
			this.rectanguloToolStripMenuItem.Size = new System.Drawing.Size(153, 24);
			this.rectanguloToolStripMenuItem.Text = "Rectangulo";
			this.rectanguloToolStripMenuItem.Click += new System.EventHandler(this.RectanguloToolStripMenuItemClick);
			// 
			// trianguloToolStripMenuItem
			// 
			this.trianguloToolStripMenuItem.Name = "trianguloToolStripMenuItem";
			this.trianguloToolStripMenuItem.Size = new System.Drawing.Size(153, 24);
			this.trianguloToolStripMenuItem.Text = "Triangulo";
			this.trianguloToolStripMenuItem.Click += new System.EventHandler(this.TrianguloToolStripMenuItemClick);
			// 
			// perimetroToolStripMenuItem
			// 
			this.perimetroToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
									this.circurferenciaToolStripMenuItem,
									this.trapecioToolStripMenuItem});
			this.perimetroToolStripMenuItem.Name = "perimetroToolStripMenuItem";
			this.perimetroToolStripMenuItem.Size = new System.Drawing.Size(85, 24);
			this.perimetroToolStripMenuItem.Text = "Perimetro";
			// 
			// circurferenciaToolStripMenuItem
			// 
			this.circurferenciaToolStripMenuItem.Name = "circurferenciaToolStripMenuItem";
			this.circurferenciaToolStripMenuItem.Size = new System.Drawing.Size(169, 24);
			this.circurferenciaToolStripMenuItem.Text = "Circurferencia";
			this.circurferenciaToolStripMenuItem.Click += new System.EventHandler(this.CircurferenciaToolStripMenuItemClick);
			// 
			// trapecioToolStripMenuItem
			// 
			this.trapecioToolStripMenuItem.Name = "trapecioToolStripMenuItem";
			this.trapecioToolStripMenuItem.Size = new System.Drawing.Size(169, 24);
			this.trapecioToolStripMenuItem.Text = "Trapecio";
			this.trapecioToolStripMenuItem.Click += new System.EventHandler(this.TrapecioToolStripMenuItemClick);
			// 
			// volumenToolStripMenuItem
			// 
			this.volumenToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
									this.esferaToolStripMenuItem,
									this.cuboToolStripMenuItem,
									this.piramideToolStripMenuItem});
			this.volumenToolStripMenuItem.Name = "volumenToolStripMenuItem";
			this.volumenToolStripMenuItem.Size = new System.Drawing.Size(79, 24);
			this.volumenToolStripMenuItem.Text = "Volumen";
			// 
			// esferaToolStripMenuItem
			// 
			this.esferaToolStripMenuItem.Name = "esferaToolStripMenuItem";
			this.esferaToolStripMenuItem.Size = new System.Drawing.Size(137, 24);
			this.esferaToolStripMenuItem.Text = "Esfera";
			this.esferaToolStripMenuItem.Click += new System.EventHandler(this.EsferaToolStripMenuItemClick);
			// 
			// cuboToolStripMenuItem
			// 
			this.cuboToolStripMenuItem.Name = "cuboToolStripMenuItem";
			this.cuboToolStripMenuItem.Size = new System.Drawing.Size(137, 24);
			this.cuboToolStripMenuItem.Text = "Cubo";
			this.cuboToolStripMenuItem.Click += new System.EventHandler(this.CuboToolStripMenuItemClick);
			// 
			// piramideToolStripMenuItem
			// 
			this.piramideToolStripMenuItem.Name = "piramideToolStripMenuItem";
			this.piramideToolStripMenuItem.Size = new System.Drawing.Size(137, 24);
			this.piramideToolStripMenuItem.Text = "Piramide";
			this.piramideToolStripMenuItem.Click += new System.EventHandler(this.PiramideToolStripMenuItemClick);
			// 
			// conversionesToolStripMenuItem
			// 
			this.conversionesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
									this.longitudKmAMIToolStripMenuItem,
									this.masaToolStripMenuItem,
									this.temperaturaCAFToolStripMenuItem,
									this.tiempoSegAHorasToolStripMenuItem});
			this.conversionesToolStripMenuItem.Name = "conversionesToolStripMenuItem";
			this.conversionesToolStripMenuItem.Size = new System.Drawing.Size(108, 24);
			this.conversionesToolStripMenuItem.Text = "Conversiones";
			// 
			// longitudKmAMIToolStripMenuItem
			// 
			this.longitudKmAMIToolStripMenuItem.Name = "longitudKmAMIToolStripMenuItem";
			this.longitudKmAMIToolStripMenuItem.Size = new System.Drawing.Size(223, 24);
			this.longitudKmAMIToolStripMenuItem.Text = "Longitud (Km a MI)";
			this.longitudKmAMIToolStripMenuItem.Click += new System.EventHandler(this.LongitudKmAMIToolStripMenuItemClick);
			// 
			// masaToolStripMenuItem
			// 
			this.masaToolStripMenuItem.Name = "masaToolStripMenuItem";
			this.masaToolStripMenuItem.Size = new System.Drawing.Size(223, 24);
			this.masaToolStripMenuItem.Text = "Masa (Kg A Li)";
			this.masaToolStripMenuItem.Click += new System.EventHandler(this.MasaToolStripMenuItemClick);
			// 
			// temperaturaCAFToolStripMenuItem
			// 
			this.temperaturaCAFToolStripMenuItem.Name = "temperaturaCAFToolStripMenuItem";
			this.temperaturaCAFToolStripMenuItem.Size = new System.Drawing.Size(223, 24);
			this.temperaturaCAFToolStripMenuItem.Text = "Temperatura (°C a °F)";
			this.temperaturaCAFToolStripMenuItem.Click += new System.EventHandler(this.TemperaturaCAFToolStripMenuItemClick);
			// 
			// tiempoSegAHorasToolStripMenuItem
			// 
			this.tiempoSegAHorasToolStripMenuItem.Name = "tiempoSegAHorasToolStripMenuItem";
			this.tiempoSegAHorasToolStripMenuItem.Size = new System.Drawing.Size(223, 24);
			this.tiempoSegAHorasToolStripMenuItem.Text = "Tiempo (Seg a Horas)";
			this.tiempoSegAHorasToolStripMenuItem.Click += new System.EventHandler(this.TiempoSegAHorasToolStripMenuItemClick);
			// 
			// boletaDeCalificacionesToolStripMenuItem
			// 
			this.boletaDeCalificacionesToolStripMenuItem.Name = "boletaDeCalificacionesToolStripMenuItem";
			this.boletaDeCalificacionesToolStripMenuItem.Size = new System.Drawing.Size(180, 24);
			this.boletaDeCalificacionesToolStripMenuItem.Text = "Boleta de Calificaciones";
			this.boletaDeCalificacionesToolStripMenuItem.Click += new System.EventHandler(this.BoletaDeCalificacionesToolStripMenuItemClick);
			// 
			// pasteleriaToolStripMenuItem
			// 
			this.pasteleriaToolStripMenuItem.Name = "pasteleriaToolStripMenuItem";
			this.pasteleriaToolStripMenuItem.Size = new System.Drawing.Size(84, 24);
			this.pasteleriaToolStripMenuItem.Text = "Pasteleria";
			this.pasteleriaToolStripMenuItem.Click += new System.EventHandler(this.PasteleriaToolStripMenuItemClick);
			// 
			// empleadosToolStripMenuItem
			// 
			this.empleadosToolStripMenuItem.Name = "empleadosToolStripMenuItem";
			this.empleadosToolStripMenuItem.Size = new System.Drawing.Size(95, 24);
			this.empleadosToolStripMenuItem.Text = "Empleados";
			this.empleadosToolStripMenuItem.Click += new System.EventHandler(this.EmpleadosToolStripMenuItemClick);
			// 
			// archivoToolStripMenuItem
			// 
			this.archivoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
									this.salirToolStripMenuItem});
			this.archivoToolStripMenuItem.Name = "archivoToolStripMenuItem";
			this.archivoToolStripMenuItem.Size = new System.Drawing.Size(71, 24);
			this.archivoToolStripMenuItem.Text = "Archivo";
			// 
			// salirToolStripMenuItem
			// 
			this.salirToolStripMenuItem.Name = "salirToolStripMenuItem";
			this.salirToolStripMenuItem.Size = new System.Drawing.Size(152, 24);
			this.salirToolStripMenuItem.Text = "Salir";
			this.salirToolStripMenuItem.Click += new System.EventHandler(this.SalirToolStripMenuItemClick);
			// 
			// acercaDeToolStripMenuItem
			// 
			this.acercaDeToolStripMenuItem.Name = "acercaDeToolStripMenuItem";
			this.acercaDeToolStripMenuItem.Size = new System.Drawing.Size(89, 24);
			this.acercaDeToolStripMenuItem.Text = "Acerca De";
			this.acercaDeToolStripMenuItem.Click += new System.EventHandler(this.AcercaDeToolStripMenuItemClick);
			// 
			// frmPrincipal
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(1035, 491);
			this.Controls.Add(this.menuStrip1);
			this.IsMdiContainer = true;
			this.MainMenuStrip = this.menuStrip1;
			this.Name = "frmPrincipal";
			this.Text = "Principal";
			this.menuStrip1.ResumeLayout(false);
			this.menuStrip1.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();
		}
		private System.Windows.Forms.ToolStripMenuItem acercaDeToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem salirToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem archivoToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem empleadosToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem pasteleriaToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem boletaDeCalificacionesToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem tiempoSegAHorasToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem temperaturaCAFToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem masaToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem longitudKmAMIToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem conversionesToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem piramideToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem cuboToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem esferaToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem volumenToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem trapecioToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem circurferenciaToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem perimetroToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem trianguloToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem rectanguloToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem cuadradoToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem areaToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem finnabociToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem factorialToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem aplicacionesToolStripMenuItem;
		private System.Windows.Forms.MenuStrip menuStrip1;
		
		void FactorialToolStripMenuItemClick(object sender, System.EventArgs e)
		{
			 frmFactorial f = new frmFactorial();
            f.MdiParent = this;
            f.Show();

		}
		
		void CuadradoToolStripMenuItemClick(object sender, System.EventArgs e)
		{
			frmAreaCuadrado f = new frmAreaCuadrado();
            f.MdiParent = this;
            f.Show();

		}
		
		void RectanguloToolStripMenuItemClick(object sender, System.EventArgs e)
		{
			frmAreaRectangulo f = new frmAreaRectangulo();
            f.MdiParent = this;
            f.Show();

		}
		
		void TrianguloToolStripMenuItemClick(object sender, System.EventArgs e)
		{
			frmAreaTriangulo f = new frmAreaTriangulo();
            f.MdiParent = this;
            f.Show();

		}
		
		void CircurferenciaToolStripMenuItemClick(object sender, System.EventArgs e)
		{
			frmPerimetroCircunferencia f = new frmPerimetroCircunferencia();
            f.MdiParent = this;
            f.Show();

		}
		
		void TrapecioToolStripMenuItemClick(object sender, System.EventArgs e)
		{
 frmPerimetroTrapecio f = new frmPerimetroTrapecio();
            f.MdiParent = this;
            f.Show();
			
		}
		
		void CuboToolStripMenuItemClick(object sender, System.EventArgs e)
		{
			 frmVolumenCubo f = new frmVolumenCubo();
            f.MdiParent = this;
            f.Show();

		}
		
		void EsferaToolStripMenuItemClick(object sender, System.EventArgs e)
		{
			  frmVolumenEsfera f = new frmVolumenEsfera();
            f.MdiParent = this;
            f.Show();

		}
		
		void PiramideToolStripMenuItemClick(object sender, System.EventArgs e)
		{
			frmVolumenPiramide f = new frmVolumenPiramide();
            f.MdiParent = this;
            f.Show();

		}
		
		void LongitudKmAMIToolStripMenuItemClick(object sender, System.EventArgs e)
		{
			 frmConvLongitud f = new frmConvLongitud();
            f.MdiParent = this;
            f.Show();
		}
		
		void MasaToolStripMenuItemClick(object sender, System.EventArgs e)
		{
			frmConvMasa f = new frmConvMasa();
            f.MdiParent = this;
            f.Show();

		}
		
		void TemperaturaCAFToolStripMenuItemClick(object sender, System.EventArgs e)
		{
			frmConvTemperatura f = new frmConvTemperatura();
            f.MdiParent = this;
            f.Show();
		}
		
		void TiempoSegAHorasToolStripMenuItemClick(object sender, System.EventArgs e)
		{
			frmConvTiempo f = new frmConvTiempo();
            f.MdiParent = this;
            f.Show();

		}
		
		void EmpleadosToolStripMenuItemClick(object sender, System.EventArgs e)
		{
			frmEmpleados f = new frmEmpleados();
            f.MdiParent = this;
            f.Show();

		}
		
		void PasteleriaToolStripMenuItemClick(object sender, System.EventArgs e)
		{
			frmPasteleria f = new frmPasteleria();
            f.MdiParent = this;
            f.Show();

		}
		
		void BoletaDeCalificacionesToolStripMenuItemClick(object sender, System.EventArgs e)
		{
			 frmBoleta f = new frmBoleta();
            f.MdiParent = this;
            f.Show();

		}
		
		void AcercaDeToolStripMenuItemClick(object sender, System.EventArgs e)
		{
			 frmAcercaDe f = new frmAcercaDe();
            f.MdiParent = this;
            f.Show();

		}
	}
}
