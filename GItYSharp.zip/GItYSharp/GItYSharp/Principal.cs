﻿using System;
using System.Windows.Forms;

namespace GItYSharp
{
    public partial class frmPrincipal : Form
    {
        public frmPrincipal()
        {
            InitializeComponent();
            this.IsMdiContainer = true; // convierte el form en contenedor MDI
        }

        // Aplicaciones
        private void fibonacciToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmFibonacci f = new frmFibonacci();
            f.MdiParent = this;
            f.Show();
        }

        private void factorialToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmFactorial f = new frmFactorial();
            f.MdiParent = this;
            f.Show();
        }

        // Área
        private void cuadradoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmAreaCuadrado f = new frmAreaCuadrado();
            f.MdiParent = this;
            f.Show();
        }

        private void rectanguloToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmAreaRectangulo f = new frmAreaRectangulo();
            f.MdiParent = this;
            f.Show();
        }

        private void trianguloToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmAreaTriangulo f = new frmAreaTriangulo();
            f.MdiParent = this;
            f.Show();
        }

        // Perímetro
        private void trapecioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmPerimetroTrapecio f = new frmPerimetroTrapecio();
            f.MdiParent = this;
            f.Show();
        }

        private void circunferenciaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmPerimetroCircunferencia f = new frmPerimetroCircunferencia();
            f.MdiParent = this;
            f.Show();
        }

        // Volumen
        private void cuboToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmVolumenCubo f = new frmVolumenCubo();
            f.MdiParent = this;
            f.Show();
        }

        private void esferaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmVolumenEsfera f = new frmVolumenEsfera();
            f.MdiParent = this;
            f.Show();
        }

        private void piramideToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmVolumenPiramide f = new frmVolumenPiramide();
            f.MdiParent = this;
            f.Show();
        }

        private void volumenEsferaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmVolumenEsfera f = new frmVolumenEsfera();
            f.MdiParent = this;
            f.Show();
        }

        // Conversiones
        private void longitudToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmConvLongitud f = new frmConvLongitud();
            f.MdiParent = this;
            f.Show();
        }

        private void masaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmConvMasa f = new frmConvMasa();
            f.MdiParent = this;
            f.Show();
        }

        private void temperaturaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmConvTemperatura f = new frmConvTemperatura();
            f.MdiParent = this;
            f.Show();
        }

        private void tiempoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmConvTiempo f = new frmConvTiempo();
            f.MdiParent = this;
            f.Show();
        }

        // Otros módulos
        private void empleadosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmEmpleados f = new frmEmpleados();
            f.MdiParent = this;
            f.Show();
        }

        private void pasteleriaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmPasteleria f = new frmPasteleria();
            f.MdiParent = this;
            f.Show();
        }

        private void boletaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmBoleta f = new frmBoleta();
            f.MdiParent = this;
            f.Show();
        }

        private void acercaDeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmAcercaDe f = new frmAcercaDe();
            f.MdiParent = this;
            f.Show();
        }
		
		void FinnabociToolStripMenuItemClick(object sender, EventArgs e)
		{
			frmFibonacci f = new frmFibonacci();
            f.MdiParent = this;
            f.Show();

		}
		
		void SalirToolStripMenuItemClick(object sender, EventArgs e)
		{
			Close();
		}
    }
}