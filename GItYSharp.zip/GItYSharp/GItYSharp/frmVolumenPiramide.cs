﻿/*
 * Creado por SharpDevelop.
 * Usuario: olive
 * Fecha: 12/14/2025
 * Hora: 4:42 PM
 * 
 * Para cambiar esta plantilla use Herramientas | Opciones | Codificación | Editar Encabezados Estándar
 */
using System;
using System.Drawing;
using System.Windows.Forms;

namespace GItYSharp
{
	/// <summary>
	/// Description of frmVolumenPiramide.
	/// </summary>
	public partial class frmVolumenPiramide : Form
	{
		public frmVolumenPiramide()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
		void Button1Click(object sender, EventArgs e)
		{
	
    string[] datos = textBox1.Text.Split(',');
    if (datos.Length != 2)
    {
        MessageBox.Show("Formato: base,altura (ejemplo: 6,10)");
        return;
    }

    double b, h;
    if (!double.TryParse(datos[0], out b) || !double.TryParse(datos[1], out h) || b <= 0 || h <= 0)
    {
        MessageBox.Show("Valores inválidos");
        return;
    }

    double volumen = (b * b * h) / 3;
    label1.Text = "Volumen de la pirámide = " + volumen;

		}
	}
}
