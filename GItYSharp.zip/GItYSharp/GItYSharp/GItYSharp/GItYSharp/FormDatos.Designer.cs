﻿/*
 * Creado por SharpDevelop.
 * Usuario: EliteBook 840 G7
 * Fecha: 30/11/2025
 * Hora: 08:41 a. m.
 * 
 * Para cambiar esta plantilla use Herramientas | Opciones | Codificación | Editar Encabezados Estándar
 */
namespace tra
{
	partial class FormDatos
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			this.txtResultado = new System.Windows.Forms.TextBox();
			this.SuspendLayout();
			// 
			// txtResultado
			// 
			this.txtResultado.Location = new System.Drawing.Point(57, 12);
			this.txtResultado.Multiline = true;
			this.txtResultado.Name = "txtResultado";
			this.txtResultado.Size = new System.Drawing.Size(422, 327);
			this.txtResultado.TabIndex = 0;
			// 
			// FormDatos
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(587, 361);
			this.Controls.Add(this.txtResultado);
			this.Name = "FormDatos";
			this.Text = "FormDatos";
			this.Load += new System.EventHandler(this.FormDatosLoad);
			this.ResumeLayout(false);
			this.PerformLayout();
		}
		private System.Windows.Forms.TextBox txtResultado;
	}
}
