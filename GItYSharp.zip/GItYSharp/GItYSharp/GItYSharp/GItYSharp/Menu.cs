﻿/*
 * Creado por SharpDevelop.
 * Usuario: olive
 * Fecha: 11/28/2025
 * Hora: 6:42 PM
 * 
 * Para cambiar esta plantilla use Herramientas | Opciones | Codificación | Editar Encabezados Estándar
 */
using System;
using System.Drawing;
using System.Windows.Forms;

namespace GItYSharp
{
	/// <summary>
	/// Description of Menu.
	/// </summary>
	public partial class frmMenu : Form
	{
		public frmMenu()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
		void BtnDatosAlumnoClick(object sender, EventArgs e)
		{
			FrmDatosAlumnos f = new FrmDatosAlumnos();
			f.Show();
		}
		
		void BtnCalificacionesClick(object sender, EventArgs e)
		{
			frmCalculoCalificaciones fCalculo = new frmCalculoCalificaciones();
			fCalculo.Show();
		}
		
		void BtnGeneradorNumClick(object sender, EventArgs e)
		{
			frmGeneradorNum fGenera = new frmGeneradorNum();
			fGenera.Show();
		}
	}
}
