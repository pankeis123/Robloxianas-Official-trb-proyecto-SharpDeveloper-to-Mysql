﻿/*
 * Creado por SharpDevelop.
 * Usuario: jesus
 * Fecha: 29/11/2025
 * Hora: 03:05 p. m.
 * 
 * Para cambiar esta plantilla use Herramientas | Opciones | Codificación | Editar Encabezados Estándar
 */
namespace GItYSharp
{
	partial class FrmMostrarDatos
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			this.lblNombre = new System.Windows.Forms.Label();
			this.lblTitulo = new System.Windows.Forms.Label();
			this.lblEdad = new System.Windows.Forms.Label();
			this.lblCURP = new System.Windows.Forms.Label();
			this.lblGrado = new System.Windows.Forms.Label();
			this.lblMostrarNombre = new System.Windows.Forms.Label();
			this.lblMostrarEdad = new System.Windows.Forms.Label();
			this.lblMostrarCURP = new System.Windows.Forms.Label();
			this.lblMostrarGrado = new System.Windows.Forms.Label();
			this.btnCerrar = new System.Windows.Forms.Button();
			this.lblGrupo = new System.Windows.Forms.Label();
			this.lblMostrarGrupo = new System.Windows.Forms.Label();
			this.lblApellido = new System.Windows.Forms.Label();
			this.lblMostrarApellido = new System.Windows.Forms.Label();
			this.lblTelefono = new System.Windows.Forms.Label();
			this.lblMostrarTelefono = new System.Windows.Forms.Label();
			this.lblEmail = new System.Windows.Forms.Label();
			this.lblMostrarEmail = new System.Windows.Forms.Label();
			this.lblCiudad = new System.Windows.Forms.Label();
			this.lblMostrarCiudad = new System.Windows.Forms.Label();
			this.lblDireccion = new System.Windows.Forms.Label();
			this.lblMostrarDireccion = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// lblNombre
			// 
			this.lblNombre.Location = new System.Drawing.Point(0, 54);
			this.lblNombre.Name = "lblNombre";
			this.lblNombre.Size = new System.Drawing.Size(100, 23);
			this.lblNombre.TabIndex = 0;
			this.lblNombre.Text = "Nombre:";
			// 
			// lblTitulo
			// 
			this.lblTitulo.Font = new System.Drawing.Font("Modern No. 20", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblTitulo.Location = new System.Drawing.Point(0, 9);
			this.lblTitulo.Name = "lblTitulo";
			this.lblTitulo.Size = new System.Drawing.Size(388, 35);
			this.lblTitulo.TabIndex = 1;
			this.lblTitulo.Text = "DATOS DEL ALUMNO";
			// 
			// lblEdad
			// 
			this.lblEdad.Location = new System.Drawing.Point(278, 130);
			this.lblEdad.Name = "lblEdad";
			this.lblEdad.Size = new System.Drawing.Size(100, 23);
			this.lblEdad.TabIndex = 2;
			this.lblEdad.Text = "Edad:";
			// 
			// lblCURP
			// 
			this.lblCURP.Location = new System.Drawing.Point(0, 130);
			this.lblCURP.Name = "lblCURP";
			this.lblCURP.Size = new System.Drawing.Size(100, 23);
			this.lblCURP.TabIndex = 3;
			this.lblCURP.Text = "CURP:";
			// 
			// lblGrado
			// 
			this.lblGrado.Location = new System.Drawing.Point(244, 89);
			this.lblGrado.Name = "lblGrado";
			this.lblGrado.Size = new System.Drawing.Size(100, 23);
			this.lblGrado.TabIndex = 4;
			this.lblGrado.Text = "Grado:";
			// 
			// lblMostrarNombre
			// 
			this.lblMostrarNombre.BackColor = System.Drawing.SystemColors.ButtonHighlight;
			this.lblMostrarNombre.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblMostrarNombre.Location = new System.Drawing.Point(65, 53);
			this.lblMostrarNombre.Name = "lblMostrarNombre";
			this.lblMostrarNombre.Size = new System.Drawing.Size(173, 23);
			this.lblMostrarNombre.TabIndex = 5;
			// 
			// lblMostrarEdad
			// 
			this.lblMostrarEdad.BackColor = System.Drawing.SystemColors.ButtonHighlight;
			this.lblMostrarEdad.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblMostrarEdad.Location = new System.Drawing.Point(323, 129);
			this.lblMostrarEdad.Name = "lblMostrarEdad";
			this.lblMostrarEdad.Size = new System.Drawing.Size(110, 23);
			this.lblMostrarEdad.TabIndex = 6;
			// 
			// lblMostrarCURP
			// 
			this.lblMostrarCURP.BackColor = System.Drawing.SystemColors.ButtonHighlight;
			this.lblMostrarCURP.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblMostrarCURP.Location = new System.Drawing.Point(65, 130);
			this.lblMostrarCURP.Name = "lblMostrarCURP";
			this.lblMostrarCURP.Size = new System.Drawing.Size(198, 23);
			this.lblMostrarCURP.TabIndex = 7;
			// 
			// lblMostrarGrado
			// 
			this.lblMostrarGrado.BackColor = System.Drawing.SystemColors.ButtonHighlight;
			this.lblMostrarGrado.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblMostrarGrado.Location = new System.Drawing.Point(303, 88);
			this.lblMostrarGrado.Name = "lblMostrarGrado";
			this.lblMostrarGrado.Size = new System.Drawing.Size(130, 23);
			this.lblMostrarGrado.TabIndex = 8;
			// 
			// btnCerrar
			// 
			this.btnCerrar.Location = new System.Drawing.Point(182, 270);
			this.btnCerrar.Name = "btnCerrar";
			this.btnCerrar.Size = new System.Drawing.Size(107, 23);
			this.btnCerrar.TabIndex = 9;
			this.btnCerrar.Text = "CERRAR";
			this.btnCerrar.UseVisualStyleBackColor = true;
			// 
			// lblGrupo
			// 
			this.lblGrupo.Location = new System.Drawing.Point(244, 53);
			this.lblGrupo.Name = "lblGrupo";
			this.lblGrupo.Size = new System.Drawing.Size(100, 23);
			this.lblGrupo.TabIndex = 10;
			this.lblGrupo.Text = "Grupo:";
			// 
			// lblMostrarGrupo
			// 
			this.lblMostrarGrupo.BackColor = System.Drawing.SystemColors.ButtonHighlight;
			this.lblMostrarGrupo.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblMostrarGrupo.Location = new System.Drawing.Point(303, 52);
			this.lblMostrarGrupo.Name = "lblMostrarGrupo";
			this.lblMostrarGrupo.Size = new System.Drawing.Size(130, 23);
			this.lblMostrarGrupo.TabIndex = 11;
			// 
			// lblApellido
			// 
			this.lblApellido.Location = new System.Drawing.Point(0, 89);
			this.lblApellido.Name = "lblApellido";
			this.lblApellido.Size = new System.Drawing.Size(100, 23);
			this.lblApellido.TabIndex = 12;
			this.lblApellido.Text = "Apellido";
			// 
			// lblMostrarApellido
			// 
			this.lblMostrarApellido.BackColor = System.Drawing.SystemColors.ButtonHighlight;
			this.lblMostrarApellido.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblMostrarApellido.Location = new System.Drawing.Point(65, 88);
			this.lblMostrarApellido.Name = "lblMostrarApellido";
			this.lblMostrarApellido.Size = new System.Drawing.Size(173, 23);
			this.lblMostrarApellido.TabIndex = 13;
			// 
			// lblTelefono
			// 
			this.lblTelefono.Location = new System.Drawing.Point(0, 165);
			this.lblTelefono.Name = "lblTelefono";
			this.lblTelefono.Size = new System.Drawing.Size(100, 23);
			this.lblTelefono.TabIndex = 14;
			this.lblTelefono.Text = "Telefono:";
			// 
			// lblMostrarTelefono
			// 
			this.lblMostrarTelefono.BackColor = System.Drawing.SystemColors.ButtonHighlight;
			this.lblMostrarTelefono.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblMostrarTelefono.Location = new System.Drawing.Point(65, 165);
			this.lblMostrarTelefono.Name = "lblMostrarTelefono";
			this.lblMostrarTelefono.Size = new System.Drawing.Size(125, 23);
			this.lblMostrarTelefono.TabIndex = 15;
			// 
			// lblEmail
			// 
			this.lblEmail.Location = new System.Drawing.Point(208, 166);
			this.lblEmail.Name = "lblEmail";
			this.lblEmail.Size = new System.Drawing.Size(100, 23);
			this.lblEmail.TabIndex = 16;
			this.lblEmail.Text = "Email:";
			// 
			// lblMostrarEmail
			// 
			this.lblMostrarEmail.BackColor = System.Drawing.SystemColors.ButtonHighlight;
			this.lblMostrarEmail.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblMostrarEmail.Location = new System.Drawing.Point(262, 166);
			this.lblMostrarEmail.Name = "lblMostrarEmail";
			this.lblMostrarEmail.Size = new System.Drawing.Size(171, 23);
			this.lblMostrarEmail.TabIndex = 17;
			// 
			// lblCiudad
			// 
			this.lblCiudad.Location = new System.Drawing.Point(0, 209);
			this.lblCiudad.Name = "lblCiudad";
			this.lblCiudad.Size = new System.Drawing.Size(100, 23);
			this.lblCiudad.TabIndex = 18;
			this.lblCiudad.Text = "Ciudad:";
			// 
			// lblMostrarCiudad
			// 
			this.lblMostrarCiudad.BackColor = System.Drawing.SystemColors.ButtonHighlight;
			this.lblMostrarCiudad.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblMostrarCiudad.Location = new System.Drawing.Point(65, 209);
			this.lblMostrarCiudad.Name = "lblMostrarCiudad";
			this.lblMostrarCiudad.Size = new System.Drawing.Size(125, 23);
			this.lblMostrarCiudad.TabIndex = 19;
			// 
			// lblDireccion
			// 
			this.lblDireccion.Location = new System.Drawing.Point(208, 209);
			this.lblDireccion.Name = "lblDireccion";
			this.lblDireccion.Size = new System.Drawing.Size(100, 23);
			this.lblDireccion.TabIndex = 20;
			this.lblDireccion.Text = "Direccion:";
			// 
			// lblMostrarDireccion
			// 
			this.lblMostrarDireccion.BackColor = System.Drawing.SystemColors.ButtonHighlight;
			this.lblMostrarDireccion.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblMostrarDireccion.Location = new System.Drawing.Point(278, 209);
			this.lblMostrarDireccion.Name = "lblMostrarDireccion";
			this.lblMostrarDireccion.Size = new System.Drawing.Size(155, 23);
			this.lblMostrarDireccion.TabIndex = 21;
			// 
			// FrmMostrarDatos
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(460, 335);
			this.Controls.Add(this.lblMostrarDireccion);
			this.Controls.Add(this.lblDireccion);
			this.Controls.Add(this.lblMostrarCiudad);
			this.Controls.Add(this.lblCiudad);
			this.Controls.Add(this.lblMostrarEmail);
			this.Controls.Add(this.lblEmail);
			this.Controls.Add(this.lblMostrarTelefono);
			this.Controls.Add(this.lblTelefono);
			this.Controls.Add(this.lblMostrarApellido);
			this.Controls.Add(this.lblApellido);
			this.Controls.Add(this.lblMostrarGrupo);
			this.Controls.Add(this.lblGrupo);
			this.Controls.Add(this.btnCerrar);
			this.Controls.Add(this.lblMostrarGrado);
			this.Controls.Add(this.lblMostrarCURP);
			this.Controls.Add(this.lblMostrarEdad);
			this.Controls.Add(this.lblMostrarNombre);
			this.Controls.Add(this.lblGrado);
			this.Controls.Add(this.lblCURP);
			this.Controls.Add(this.lblEdad);
			this.Controls.Add(this.lblTitulo);
			this.Controls.Add(this.lblNombre);
			this.Name = "FrmMostrarDatos";
			this.Text = "Datos mostrados del alumno";
			this.ResumeLayout(false);
		}
		private System.Windows.Forms.Label lblMostrarDireccion;
		private System.Windows.Forms.Label lblDireccion;
		private System.Windows.Forms.Label lblMostrarCiudad;
		private System.Windows.Forms.Label lblCiudad;
		private System.Windows.Forms.Label lblMostrarEmail;
		private System.Windows.Forms.Label lblEmail;
		private System.Windows.Forms.Label lblMostrarTelefono;
		private System.Windows.Forms.Label lblTelefono;
		private System.Windows.Forms.Label lblMostrarApellido;
		private System.Windows.Forms.Label lblApellido;
		private System.Windows.Forms.Label lblMostrarGrupo;
		private System.Windows.Forms.Label lblGrupo;
		private System.Windows.Forms.Button btnCerrar;
		private System.Windows.Forms.Label lblMostrarGrado;
		private System.Windows.Forms.Label lblMostrarCURP;
		private System.Windows.Forms.Label lblMostrarEdad;
		private System.Windows.Forms.Label lblMostrarNombre;
		private System.Windows.Forms.Label lblGrado;
		private System.Windows.Forms.Label lblCURP;
		private System.Windows.Forms.Label lblEdad;
		private System.Windows.Forms.Label lblTitulo;
		private System.Windows.Forms.Label lblNombre;
	}
}
