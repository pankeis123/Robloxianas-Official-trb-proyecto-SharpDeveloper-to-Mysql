﻿/*
 * Creado por SharpDevelop.
 * Usuario: jesus
 * Fecha: 29/11/2025
 * Hora: 03:05 p. m.
 * 
 * Para cambiar esta plantilla use Herramientas | Opciones | Codificación | Editar Encabezados Estándar
 */
namespace GItYSharp
{
	partial class FrmDatosAlumnos
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			this.lblNombre = new System.Windows.Forms.Label();
			this.lblApellido = new System.Windows.Forms.Label();
			this.lblEdad = new System.Windows.Forms.Label();
			this.lblGrupo = new System.Windows.Forms.Label();
			this.lblCiudad = new System.Windows.Forms.Label();
			this.lblTelefono = new System.Windows.Forms.Label();
			this.lblEmail = new System.Windows.Forms.Label();
			this.lblNombreTuto = new System.Windows.Forms.Label();
			this.lblDireccion = new System.Windows.Forms.Label();
			this.lblMatricula = new System.Windows.Forms.Label();
			this.txtNombre = new System.Windows.Forms.TextBox();
			this.txtApellido = new System.Windows.Forms.TextBox();
			this.txtEdad = new System.Windows.Forms.TextBox();
			this.txtMatricula = new System.Windows.Forms.TextBox();
			this.txtGrupo = new System.Windows.Forms.TextBox();
			this.txtGrado = new System.Windows.Forms.TextBox();
			this.txtCiudad = new System.Windows.Forms.TextBox();
			this.txtEmail = new System.Windows.Forms.TextBox();
			this.txtTelefono = new System.Windows.Forms.TextBox();
			this.txtDireccion = new System.Windows.Forms.TextBox();
			this.btnGuardar = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// lblNombre
			// 
			this.lblNombre.Location = new System.Drawing.Point(21, 29);
			this.lblNombre.Name = "lblNombre";
			this.lblNombre.Size = new System.Drawing.Size(100, 23);
			this.lblNombre.TabIndex = 0;
			this.lblNombre.Text = "Nombre:";
			// 
			// lblApellido
			// 
			this.lblApellido.Location = new System.Drawing.Point(268, 29);
			this.lblApellido.Name = "lblApellido";
			this.lblApellido.Size = new System.Drawing.Size(100, 23);
			this.lblApellido.TabIndex = 1;
			this.lblApellido.Text = "Apellido:";
			// 
			// lblEdad
			// 
			this.lblEdad.Location = new System.Drawing.Point(21, 76);
			this.lblEdad.Name = "lblEdad";
			this.lblEdad.Size = new System.Drawing.Size(100, 23);
			this.lblEdad.TabIndex = 2;
			this.lblEdad.Text = "Edad:";
			// 
			// lblGrupo
			// 
			this.lblGrupo.Location = new System.Drawing.Point(21, 125);
			this.lblGrupo.Name = "lblGrupo";
			this.lblGrupo.Size = new System.Drawing.Size(100, 23);
			this.lblGrupo.TabIndex = 3;
			this.lblGrupo.Text = "Grupo:";
			// 
			// lblCiudad
			// 
			this.lblCiudad.Location = new System.Drawing.Point(21, 178);
			this.lblCiudad.Name = "lblCiudad";
			this.lblCiudad.Size = new System.Drawing.Size(100, 23);
			this.lblCiudad.TabIndex = 4;
			this.lblCiudad.Text = "Ciudad:";
			// 
			// lblTelefono
			// 
			this.lblTelefono.Location = new System.Drawing.Point(21, 233);
			this.lblTelefono.Name = "lblTelefono";
			this.lblTelefono.Size = new System.Drawing.Size(100, 23);
			this.lblTelefono.TabIndex = 5;
			this.lblTelefono.Text = "Telefono:";
			// 
			// lblEmail
			// 
			this.lblEmail.Location = new System.Drawing.Point(203, 177);
			this.lblEmail.Name = "lblEmail";
			this.lblEmail.Size = new System.Drawing.Size(100, 23);
			this.lblEmail.TabIndex = 6;
			this.lblEmail.Text = "Email:";
			// 
			// lblNombreTuto
			// 
			this.lblNombreTuto.Location = new System.Drawing.Point(203, 125);
			this.lblNombreTuto.Name = "lblNombreTuto";
			this.lblNombreTuto.Size = new System.Drawing.Size(126, 23);
			this.lblNombreTuto.TabIndex = 7;
			this.lblNombreTuto.Text = "Grado:";
			// 
			// lblDireccion
			// 
			this.lblDireccion.Location = new System.Drawing.Point(241, 233);
			this.lblDireccion.Name = "lblDireccion";
			this.lblDireccion.Size = new System.Drawing.Size(100, 23);
			this.lblDireccion.TabIndex = 8;
			this.lblDireccion.Text = "Direccion:";
			// 
			// lblMatricula
			// 
			this.lblMatricula.Location = new System.Drawing.Point(166, 76);
			this.lblMatricula.Name = "lblMatricula";
			this.lblMatricula.Size = new System.Drawing.Size(100, 23);
			this.lblMatricula.TabIndex = 9;
			this.lblMatricula.Text = "Matricula:";
			// 
			// txtNombre
			// 
			this.txtNombre.Location = new System.Drawing.Point(94, 29);
			this.txtNombre.Name = "txtNombre";
			this.txtNombre.Size = new System.Drawing.Size(172, 22);
			this.txtNombre.TabIndex = 10;
			// 
			// txtApellido
			// 
			this.txtApellido.Location = new System.Drawing.Point(330, 29);
			this.txtApellido.Name = "txtApellido";
			this.txtApellido.Size = new System.Drawing.Size(201, 22);
			this.txtApellido.TabIndex = 11;
			// 
			// txtEdad
			// 
			this.txtEdad.Location = new System.Drawing.Point(71, 76);
			this.txtEdad.Name = "txtEdad";
			this.txtEdad.Size = new System.Drawing.Size(76, 22);
			this.txtEdad.TabIndex = 12;
			// 
			// txtMatricula
			// 
			this.txtMatricula.Location = new System.Drawing.Point(241, 76);
			this.txtMatricula.Name = "txtMatricula";
			this.txtMatricula.Size = new System.Drawing.Size(238, 22);
			this.txtMatricula.TabIndex = 13;
			// 
			// txtGrupo
			// 
			this.txtGrupo.Location = new System.Drawing.Point(80, 125);
			this.txtGrupo.Name = "txtGrupo";
			this.txtGrupo.Size = new System.Drawing.Size(117, 22);
			this.txtGrupo.TabIndex = 14;
			// 
			// txtGrado
			// 
			this.txtGrado.Location = new System.Drawing.Point(259, 126);
			this.txtGrado.Name = "txtGrado";
			this.txtGrado.Size = new System.Drawing.Size(204, 22);
			this.txtGrado.TabIndex = 15;
			// 
			// txtCiudad
			// 
			this.txtCiudad.Location = new System.Drawing.Point(80, 178);
			this.txtCiudad.Name = "txtCiudad";
			this.txtCiudad.Size = new System.Drawing.Size(117, 22);
			this.txtCiudad.TabIndex = 16;
			// 
			// txtEmail
			// 
			this.txtEmail.Location = new System.Drawing.Point(268, 177);
			this.txtEmail.Name = "txtEmail";
			this.txtEmail.Size = new System.Drawing.Size(195, 22);
			this.txtEmail.TabIndex = 17;
			// 
			// txtTelefono
			// 
			this.txtTelefono.Location = new System.Drawing.Point(97, 233);
			this.txtTelefono.Name = "txtTelefono";
			this.txtTelefono.Size = new System.Drawing.Size(138, 22);
			this.txtTelefono.TabIndex = 18;
			// 
			// txtDireccion
			// 
			this.txtDireccion.Location = new System.Drawing.Point(317, 234);
			this.txtDireccion.Name = "txtDireccion";
			this.txtDireccion.Size = new System.Drawing.Size(146, 22);
			this.txtDireccion.TabIndex = 19;
			// 
			// btnGuardar
			// 
			this.btnGuardar.Location = new System.Drawing.Point(203, 301);
			this.btnGuardar.Name = "btnGuardar";
			this.btnGuardar.Size = new System.Drawing.Size(75, 23);
			this.btnGuardar.TabIndex = 20;
			this.btnGuardar.Text = "Guardar";
			this.btnGuardar.UseVisualStyleBackColor = true;
			this.btnGuardar.Click += new System.EventHandler(this.BtnGuardarClick);
			// 
			// FrmDatosAlumnos
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(543, 414);
			this.Controls.Add(this.btnGuardar);
			this.Controls.Add(this.txtDireccion);
			this.Controls.Add(this.txtTelefono);
			this.Controls.Add(this.txtEmail);
			this.Controls.Add(this.txtCiudad);
			this.Controls.Add(this.txtGrado);
			this.Controls.Add(this.txtGrupo);
			this.Controls.Add(this.txtMatricula);
			this.Controls.Add(this.txtEdad);
			this.Controls.Add(this.txtApellido);
			this.Controls.Add(this.txtNombre);
			this.Controls.Add(this.lblMatricula);
			this.Controls.Add(this.lblDireccion);
			this.Controls.Add(this.lblNombreTuto);
			this.Controls.Add(this.lblEmail);
			this.Controls.Add(this.lblTelefono);
			this.Controls.Add(this.lblCiudad);
			this.Controls.Add(this.lblGrupo);
			this.Controls.Add(this.lblEdad);
			this.Controls.Add(this.lblApellido);
			this.Controls.Add(this.lblNombre);
			this.Name = "FrmDatosAlumnos";
			this.Text = "Datos de Alumno";
			this.ResumeLayout(false);
			this.PerformLayout();
		}
		private System.Windows.Forms.Button btnGuardar;
		private System.Windows.Forms.TextBox txtDireccion;
		private System.Windows.Forms.TextBox txtTelefono;
		private System.Windows.Forms.TextBox txtEmail;
		private System.Windows.Forms.TextBox txtCiudad;
		private System.Windows.Forms.TextBox txtGrado;
		private System.Windows.Forms.TextBox txtGrupo;
		private System.Windows.Forms.TextBox txtMatricula;
		private System.Windows.Forms.TextBox txtEdad;
		private System.Windows.Forms.TextBox txtApellido;
		private System.Windows.Forms.TextBox txtNombre;
		private System.Windows.Forms.Label lblMatricula;
		private System.Windows.Forms.Label lblDireccion;
		private System.Windows.Forms.Label lblNombreTuto;
		private System.Windows.Forms.Label lblEmail;
		private System.Windows.Forms.Label lblTelefono;
		private System.Windows.Forms.Label lblCiudad;
		private System.Windows.Forms.Label lblGrupo;
		private System.Windows.Forms.Label lblEdad;
		private System.Windows.Forms.Label lblApellido;
		private System.Windows.Forms.Label lblNombre;
	}
}
