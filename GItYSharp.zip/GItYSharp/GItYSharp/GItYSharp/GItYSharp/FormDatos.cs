﻿/*
 * Creado por SharpDevelop.
 * Usuario: EliteBook 840 G7
 * Fecha: 30/11/2025
 * Hora: 08:41 a. m.
 * 
 * Para cambiar esta plantilla use Herramientas | Opciones | Codificación | Editar Encabezados Estándar
 */
using System;
using System.Drawing;
using System.Windows.Forms;

namespace tra
{
	/// <summary>
	/// Description of FormDatos.
	/// </summary>
	

		
			
public partial class FormDatos : Form
{
    private Alumno alumno;

    public FormDatos(Alumno datosRecibidos)
    {
        InitializeComponent();
        alumno = datosRecibidos;
 

   	
		}
		
		void FormDatosLoad(object sender, EventArgs e)
		{
			  txtResultado.Text =
        "Matricula: " + alumno.Matricula + "\r\n" +
        "Nombre: " + alumno.Nombre + "\r\n" +
        "Apellido: " + alumno.Apellido + "\r\n" +
        "Edad: " + alumno.Edad + "\r\n" +
        "Genero: " + alumno.Genero + "\r\n" +
        "Fecha de Nacimiento: " + alumno.FechaNacimiento + "\r\n" +
        "Carrera: " + alumno.Carrera + "\r\n" +
        "Semestre: " + alumno.Semestre + "\r\n" +
        "Correo: " + alumno.Correo + "\r\n" +
        "Telefono: " + alumno.Telefono;
		}
}
	}

