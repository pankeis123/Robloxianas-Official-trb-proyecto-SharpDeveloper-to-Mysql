﻿/*
 * Creado por SharpDevelop.
 * Usuario: jesus
 * Fecha: 29/11/2025
 * Hora: 03:05 p. m.
 * 
 * Para cambiar esta plantilla use Herramientas | Opciones | Codificación | Editar Encabezados Estándar
 */
using System;
using System.Drawing;
using System.Windows.Forms;

namespace GItYSharp
{
	/// <summary>
	/// Description of Form1.
	/// </summary>
	public partial class FrmDatosAlumnos : Form
	{
		public FrmDatosAlumnos()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();}
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
			public class Alumno
			{
				public string Nombre { get; set; }
				public string Apellido { get; set; }
				public string Edad { get; set; }
				public string Matricula { get; set; }
				public string Grupo { get; set; }
				public string Grado { get; set; }
				public string Telefono { get; set; }
				public string Email { get; set; }
				public string Ciudad { get; set; }
				public string Direccion { get; set; }
			}
		
		void BtnGuardarClick(object sender, EventArgs e)
		{
			Alumno alumno = new Alumno()
        {
            Matricula = txtMatricula.Text,
            Nombre = txtNombre.Text,
            Apellido = txtApellido.Text,
            Edad = txtEdad.Text,
            Grupo = txtGrupo.Text,
            Grado = txtGrado.Text,
            Direccion = txtDireccion.Text,
            Email = txtEmail.Text,
            Ciudad = txtCiudad.Text,
            Telefono = txtTelefono.Text
        };

 
 
		}
	}
}
