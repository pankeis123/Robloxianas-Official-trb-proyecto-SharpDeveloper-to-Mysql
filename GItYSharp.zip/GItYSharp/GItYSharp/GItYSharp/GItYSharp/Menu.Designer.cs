﻿/*
 * Creado por SharpDevelop.
 * Usuario: olive
 * Fecha: 11/28/2025
 * Hora: 6:42 PM
 * 
 * Para cambiar esta plantilla use Herramientas | Opciones | Codificación | Editar Encabezados Estándar
 */
namespace GItYSharp
{
	partial class frmMenu
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			this.btnCalificaciones = new System.Windows.Forms.Button();
			this.btnGeneradorNum = new System.Windows.Forms.Button();
			this.btnDatosAlumno = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// btnCalificaciones
			// 
			this.btnCalificaciones.Font = new System.Drawing.Font("Modern No. 20", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnCalificaciones.Location = new System.Drawing.Point(12, 134);
			this.btnCalificaciones.Name = "btnCalificaciones";
			this.btnCalificaciones.Size = new System.Drawing.Size(343, 31);
			this.btnCalificaciones.TabIndex = 0;
			this.btnCalificaciones.Text = "Calculo de calificaciones";
			this.btnCalificaciones.UseVisualStyleBackColor = true;
			this.btnCalificaciones.Click += new System.EventHandler(this.BtnCalificacionesClick);
			// 
			// btnGeneradorNum
			// 
			this.btnGeneradorNum.Font = new System.Drawing.Font("Modern No. 20", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnGeneradorNum.Location = new System.Drawing.Point(12, 196);
			this.btnGeneradorNum.Name = "btnGeneradorNum";
			this.btnGeneradorNum.Size = new System.Drawing.Size(343, 31);
			this.btnGeneradorNum.TabIndex = 1;
			this.btnGeneradorNum.Text = "Generador de numeros";
			this.btnGeneradorNum.UseVisualStyleBackColor = true;
			this.btnGeneradorNum.Click += new System.EventHandler(this.BtnGeneradorNumClick);
			// 
			// btnDatosAlumno
			// 
			this.btnDatosAlumno.Font = new System.Drawing.Font("Modern No. 20", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnDatosAlumno.Location = new System.Drawing.Point(12, 78);
			this.btnDatosAlumno.Name = "btnDatosAlumno";
			this.btnDatosAlumno.Size = new System.Drawing.Size(343, 31);
			this.btnDatosAlumno.TabIndex = 2;
			this.btnDatosAlumno.Text = "Datos de alumno";
			this.btnDatosAlumno.UseVisualStyleBackColor = true;
			this.btnDatosAlumno.Click += new System.EventHandler(this.BtnDatosAlumnoClick);
			// 
			// label1
			// 
			this.label1.Font = new System.Drawing.Font("Modern No. 20", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.Location = new System.Drawing.Point(12, 28);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(233, 32);
			this.label1.TabIndex = 3;
			this.label1.Text = "Lista de proyectos:";
			// 
			// frmMenu
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(379, 288);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.btnDatosAlumno);
			this.Controls.Add(this.btnGeneradorNum);
			this.Controls.Add(this.btnCalificaciones);
			this.Name = "frmMenu";
			this.Text = "Menu Principal";
			this.ResumeLayout(false);
		}
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Button btnDatosAlumno;
		private System.Windows.Forms.Button btnGeneradorNum;
		private System.Windows.Forms.Button btnCalificaciones;
	}
}
