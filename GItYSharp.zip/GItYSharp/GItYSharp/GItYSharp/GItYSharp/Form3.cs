﻿/*
 * Creado por SharpDevelop.
 * Usuario: jesus
 * Fecha: 29/11/2025
 * Hora: 03:05 p. m.
 * 
 * Para cambiar esta plantilla use Herramientas | Opciones | Codificación | Editar Encabezados Estándar
 */
using System;
using System.Drawing;
using System.Windows.Forms;

namespace GItYSharp
{
	/// <summary>
	/// Description of Form3.
	/// </summary>
	public partial class frmCalculoCalificaciones : Form
	{
		public frmCalculoCalificaciones()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			btnCalculaProm.Click += new EventHandler(btnCalculaProm_Click);
		}
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
			
    private void btnCalculaProm_Click(object sender, EventArgs e)
{
        try
        {
            double[] calificaciones = new double[7];
            calificaciones[0] = Convert.ToDouble(txtCalificacion1.Text);
            calificaciones[1] = Convert.ToDouble(txtCalificacion2.Text);
            calificaciones[2] = Convert.ToDouble(txtCalificacion3.Text);
            calificaciones[3] = Convert.ToDouble(txtCalificacion4.Text);
            calificaciones[4] = Convert.ToDouble(txtCalificacion5.Text);
            calificaciones[5] = Convert.ToDouble(txtCalificacion6.Text);
            calificaciones[6] = Convert.ToDouble(txtCalificacion7.Text);

            double suma = 0;
            foreach (double cal in calificaciones)
            {
                suma += cal;
            }
            double promedio = suma / calificaciones.Length;

            lblResultado.Text = "Promedio: " + promedio.ToString("F2");
        }
        catch (FormatException)
        {
            MessageBox.Show("Por favor, ingresa solo números válidos en todas las calificaciones.");
        }
    }
}
}