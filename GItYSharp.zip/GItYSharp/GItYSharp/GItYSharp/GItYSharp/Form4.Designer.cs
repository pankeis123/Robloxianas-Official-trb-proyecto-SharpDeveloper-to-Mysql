﻿/*
 * Creado por SharpDevelop.
 * Usuario: jesus
 * Fecha: 29/11/2025
 * Hora: 03:05 p. m.
 * 
 * Para cambiar esta plantilla use Herramientas | Opciones | Codificación | Editar Encabezados Estándar
 */
namespace GItYSharp
{
	partial class frmGeneradorNum
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			this.label1 = new System.Windows.Forms.Label();
			this.btnGeneraNum = new System.Windows.Forms.Button();
			this.lblNumGenerado = new System.Windows.Forms.Label();
			this.lblNumOrdenado = new System.Windows.Forms.Label();
			this.listGenerado = new System.Windows.Forms.ListBox();
			this.listOrdenado = new System.Windows.Forms.ListBox();
			this.btnOrdenar = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.Font = new System.Drawing.Font("Modern No. 20", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.Location = new System.Drawing.Point(4, 9);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(559, 23);
			this.label1.TabIndex = 0;
			this.label1.Text = "GENERAR Y ORGANIZAR NUMEROS";
			// 
			// btnGeneraNum
			// 
			this.btnGeneraNum.Location = new System.Drawing.Point(26, 63);
			this.btnGeneraNum.Name = "btnGeneraNum";
			this.btnGeneraNum.Size = new System.Drawing.Size(155, 36);
			this.btnGeneraNum.TabIndex = 1;
			this.btnGeneraNum.Text = "Genera 10 Numeros";
			this.btnGeneraNum.UseVisualStyleBackColor = true;
			this.btnGeneraNum.Click += new System.EventHandler(this.BtnGeneraNumClick);
			// 
			// lblNumGenerado
			// 
			this.lblNumGenerado.Location = new System.Drawing.Point(26, 137);
			this.lblNumGenerado.Name = "lblNumGenerado";
			this.lblNumGenerado.Size = new System.Drawing.Size(180, 23);
			this.lblNumGenerado.TabIndex = 2;
			this.lblNumGenerado.Text = "Numeros Generados:";
			// 
			// lblNumOrdenado
			// 
			this.lblNumOrdenado.Location = new System.Drawing.Point(331, 137);
			this.lblNumOrdenado.Name = "lblNumOrdenado";
			this.lblNumOrdenado.Size = new System.Drawing.Size(180, 23);
			this.lblNumOrdenado.TabIndex = 3;
			this.lblNumOrdenado.Text = "Numeros Ordenados:";
			// 
			// listGenerado
			// 
			this.listGenerado.FormattingEnabled = true;
			this.listGenerado.ItemHeight = 16;
			this.listGenerado.Location = new System.Drawing.Point(26, 176);
			this.listGenerado.Name = "listGenerado";
			this.listGenerado.Size = new System.Drawing.Size(180, 180);
			this.listGenerado.TabIndex = 4;
			// 
			// listOrdenado
			// 
			this.listOrdenado.FormattingEnabled = true;
			this.listOrdenado.ItemHeight = 16;
			this.listOrdenado.Location = new System.Drawing.Point(331, 176);
			this.listOrdenado.Name = "listOrdenado";
			this.listOrdenado.Size = new System.Drawing.Size(180, 180);
			this.listOrdenado.TabIndex = 5;
			// 
			// btnOrdenar
			// 
			this.btnOrdenar.Location = new System.Drawing.Point(218, 379);
			this.btnOrdenar.Name = "btnOrdenar";
			this.btnOrdenar.Size = new System.Drawing.Size(94, 39);
			this.btnOrdenar.TabIndex = 6;
			this.btnOrdenar.Text = "Ordenar";
			this.btnOrdenar.UseVisualStyleBackColor = true;
			this.btnOrdenar.Click += new System.EventHandler(this.BtnOrdenarClick);
			// 
			// frmGeneradorNum
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(566, 449);
			this.Controls.Add(this.btnOrdenar);
			this.Controls.Add(this.listOrdenado);
			this.Controls.Add(this.listGenerado);
			this.Controls.Add(this.lblNumOrdenado);
			this.Controls.Add(this.lblNumGenerado);
			this.Controls.Add(this.btnGeneraNum);
			this.Controls.Add(this.label1);
			this.Name = "frmGeneradorNum";
			this.Text = "Generador de numeros";
			this.ResumeLayout(false);
		}
		private System.Windows.Forms.Button btnOrdenar;
		private System.Windows.Forms.ListBox listOrdenado;
		private System.Windows.Forms.ListBox listGenerado;
		private System.Windows.Forms.Label lblNumOrdenado;
		private System.Windows.Forms.Label lblNumGenerado;
		private System.Windows.Forms.Button btnGeneraNum;
		private System.Windows.Forms.Label label1;
	}
}
