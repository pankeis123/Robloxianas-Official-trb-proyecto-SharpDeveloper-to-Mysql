﻿/*
 * Creado por SharpDevelop.
 * Usuario: jesus
 * Fecha: 29/11/2025
 * Hora: 03:05 p. m.
 * 
 * Para cambiar esta plantilla use Herramientas | Opciones | Codificación | Editar Encabezados Estándar
 */
using System;
using System.Drawing;
using System.Windows.Forms;

namespace GItYSharp
{
	/// <summary>
	/// Description of Form2.
	/// </summary>
	public partial class FrmMostrarDatos : Form
	{
		public FrmMostrarDatos()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//	
				
		}
	}
}
