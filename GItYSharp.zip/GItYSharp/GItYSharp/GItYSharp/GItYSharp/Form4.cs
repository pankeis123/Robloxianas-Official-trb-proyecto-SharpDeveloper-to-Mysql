﻿/*
 * Creado por SharpDevelop.
 * Usuario: jesus
 * Fecha: 29/11/2025
 * Hora: 03:05 p. m.
 * 
 * Para cambiar esta plantilla use Herramientas | Opciones | Codificación | Editar Encabezados Estándar
 */
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace GItYSharp
{
	/// <summary>
	/// Description of Form4.
	/// </summary>
	public partial class frmGeneradorNum : Form
	{
		private List<int> numerosGenerado = new List<int>();
		public frmGeneradorNum()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
            
		}
		private void BtnGeneraNumClick(object sender, EventArgs e)
    {
        numerosGenerado.Clear();
        listGenerado.Items.Clear();
        listOrdenado.Items.Clear();

        Random random = new Random();

        for (int i = 0; i < 10; i++)
        {
            int numero = random.Next(1, 101); 
            
            numerosGenerado.Add(numero);
            
            listGenerado.Items.Add(numero.ToString());
        }
    }

        private void BtnOrdenarClick(object sender, EventArgs e)
    {
        if (numerosGenerado.Count == 0)
        {
            MessageBox.Show("Primero debes presionar el botón GENERAR.");
            return;
        }

        listOrdenado.Items.Clear();
        List<int> numerosOrdenados = new List<int>(numerosGenerado);
        numerosOrdenados.Sort(); 
        foreach (int numero in numerosOrdenados)
        {
           listOrdenado.Items.Add(numero.ToString());
        }
    }
}
}