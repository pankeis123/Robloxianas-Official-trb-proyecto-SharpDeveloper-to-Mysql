﻿/*
 * Creado por SharpDevelop.
 * Usuario: jesus
 * Fecha: 29/11/2025
 * Hora: 03:05 p. m.
 * 
 * Para cambiar esta plantilla use Herramientas | Opciones | Codificación | Editar Encabezados Estándar
 */
namespace GItYSharp
{
	partial class frmCalculoCalificaciones
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			this.lblCalificacion1 = new System.Windows.Forms.Label();
			this.lblCalificacion2 = new System.Windows.Forms.Label();
			this.lblCalificacion3 = new System.Windows.Forms.Label();
			this.lblCalificacion4 = new System.Windows.Forms.Label();
			this.lblCalificacion5 = new System.Windows.Forms.Label();
			this.lblCalificacion6 = new System.Windows.Forms.Label();
			this.lblCalificacion7 = new System.Windows.Forms.Label();
			this.txtCalificacion1 = new System.Windows.Forms.TextBox();
			this.txtCalificacion2 = new System.Windows.Forms.TextBox();
			this.txtCalificacion3 = new System.Windows.Forms.TextBox();
			this.txtCalificacion4 = new System.Windows.Forms.TextBox();
			this.txtCalificacion5 = new System.Windows.Forms.TextBox();
			this.txtCalificacion7 = new System.Windows.Forms.TextBox();
			this.txtCalificacion6 = new System.Windows.Forms.TextBox();
			this.btnCalculaProm = new System.Windows.Forms.Button();
			this.lblResultado = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// lblCalificacion1
			// 
			this.lblCalificacion1.Location = new System.Drawing.Point(29, 28);
			this.lblCalificacion1.Name = "lblCalificacion1";
			this.lblCalificacion1.Size = new System.Drawing.Size(157, 23);
			this.lblCalificacion1.TabIndex = 0;
			this.lblCalificacion1.Text = "Calificacion 1:";
			// 
			// lblCalificacion2
			// 
			this.lblCalificacion2.Location = new System.Drawing.Point(29, 66);
			this.lblCalificacion2.Name = "lblCalificacion2";
			this.lblCalificacion2.Size = new System.Drawing.Size(145, 23);
			this.lblCalificacion2.TabIndex = 1;
			this.lblCalificacion2.Text = "Calificacion 2:";
			// 
			// lblCalificacion3
			// 
			this.lblCalificacion3.Location = new System.Drawing.Point(29, 105);
			this.lblCalificacion3.Name = "lblCalificacion3";
			this.lblCalificacion3.Size = new System.Drawing.Size(145, 23);
			this.lblCalificacion3.TabIndex = 2;
			this.lblCalificacion3.Text = "Calificacion 3:";
			// 
			// lblCalificacion4
			// 
			this.lblCalificacion4.Location = new System.Drawing.Point(29, 139);
			this.lblCalificacion4.Name = "lblCalificacion4";
			this.lblCalificacion4.Size = new System.Drawing.Size(145, 23);
			this.lblCalificacion4.TabIndex = 3;
			this.lblCalificacion4.Text = "Calificacion 4:";
			// 
			// lblCalificacion5
			// 
			this.lblCalificacion5.Location = new System.Drawing.Point(29, 178);
			this.lblCalificacion5.Name = "lblCalificacion5";
			this.lblCalificacion5.Size = new System.Drawing.Size(145, 23);
			this.lblCalificacion5.TabIndex = 4;
			this.lblCalificacion5.Text = "Calificacion 5:";
			// 
			// lblCalificacion6
			// 
			this.lblCalificacion6.Location = new System.Drawing.Point(29, 212);
			this.lblCalificacion6.Name = "lblCalificacion6";
			this.lblCalificacion6.Size = new System.Drawing.Size(145, 23);
			this.lblCalificacion6.TabIndex = 5;
			this.lblCalificacion6.Text = "Calificacion 6:";
			// 
			// lblCalificacion7
			// 
			this.lblCalificacion7.Location = new System.Drawing.Point(29, 252);
			this.lblCalificacion7.Name = "lblCalificacion7";
			this.lblCalificacion7.Size = new System.Drawing.Size(145, 23);
			this.lblCalificacion7.TabIndex = 6;
			this.lblCalificacion7.Text = "Calificacion 7:";
			// 
			// txtCalificacion1
			// 
			this.txtCalificacion1.Location = new System.Drawing.Point(189, 28);
			this.txtCalificacion1.Name = "txtCalificacion1";
			this.txtCalificacion1.Size = new System.Drawing.Size(107, 22);
			this.txtCalificacion1.TabIndex = 7;
			// 
			// txtCalificacion2
			// 
			this.txtCalificacion2.Location = new System.Drawing.Point(189, 63);
			this.txtCalificacion2.Name = "txtCalificacion2";
			this.txtCalificacion2.Size = new System.Drawing.Size(107, 22);
			this.txtCalificacion2.TabIndex = 8;
			// 
			// txtCalificacion3
			// 
			this.txtCalificacion3.Location = new System.Drawing.Point(189, 102);
			this.txtCalificacion3.Name = "txtCalificacion3";
			this.txtCalificacion3.Size = new System.Drawing.Size(107, 22);
			this.txtCalificacion3.TabIndex = 9;
			// 
			// txtCalificacion4
			// 
			this.txtCalificacion4.Location = new System.Drawing.Point(189, 136);
			this.txtCalificacion4.Name = "txtCalificacion4";
			this.txtCalificacion4.Size = new System.Drawing.Size(107, 22);
			this.txtCalificacion4.TabIndex = 10;
			// 
			// txtCalificacion5
			// 
			this.txtCalificacion5.Location = new System.Drawing.Point(189, 175);
			this.txtCalificacion5.Name = "txtCalificacion5";
			this.txtCalificacion5.Size = new System.Drawing.Size(107, 22);
			this.txtCalificacion5.TabIndex = 11;
			// 
			// txtCalificacion7
			// 
			this.txtCalificacion7.Location = new System.Drawing.Point(189, 252);
			this.txtCalificacion7.Name = "txtCalificacion7";
			this.txtCalificacion7.Size = new System.Drawing.Size(107, 22);
			this.txtCalificacion7.TabIndex = 12;
			// 
			// txtCalificacion6
			// 
			this.txtCalificacion6.Location = new System.Drawing.Point(189, 209);
			this.txtCalificacion6.Name = "txtCalificacion6";
			this.txtCalificacion6.Size = new System.Drawing.Size(107, 22);
			this.txtCalificacion6.TabIndex = 13;
			// 
			// btnCalculaProm
			// 
			this.btnCalculaProm.Location = new System.Drawing.Point(84, 292);
			this.btnCalculaProm.Name = "btnCalculaProm";
			this.btnCalculaProm.Size = new System.Drawing.Size(145, 33);
			this.btnCalculaProm.TabIndex = 14;
			this.btnCalculaProm.Text = "Calcula el Promedio";
			this.btnCalculaProm.UseVisualStyleBackColor = true;
			// 
			// lblResultado
			// 
			this.lblResultado.Location = new System.Drawing.Point(69, 347);
			this.lblResultado.Name = "lblResultado";
			this.lblResultado.Size = new System.Drawing.Size(227, 23);
			this.lblResultado.TabIndex = 15;
			this.lblResultado.Text = "Resultado:";
			// 
			// frmCalculoCalificaciones
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(364, 379);
			this.Controls.Add(this.lblResultado);
			this.Controls.Add(this.btnCalculaProm);
			this.Controls.Add(this.txtCalificacion6);
			this.Controls.Add(this.txtCalificacion7);
			this.Controls.Add(this.txtCalificacion5);
			this.Controls.Add(this.txtCalificacion4);
			this.Controls.Add(this.txtCalificacion3);
			this.Controls.Add(this.txtCalificacion2);
			this.Controls.Add(this.txtCalificacion1);
			this.Controls.Add(this.lblCalificacion7);
			this.Controls.Add(this.lblCalificacion6);
			this.Controls.Add(this.lblCalificacion5);
			this.Controls.Add(this.lblCalificacion4);
			this.Controls.Add(this.lblCalificacion3);
			this.Controls.Add(this.lblCalificacion2);
			this.Controls.Add(this.lblCalificacion1);
			this.Name = "frmCalculoCalificaciones";
			this.Text = "Calculo de calificaciones";
			this.ResumeLayout(false);
			this.PerformLayout();
		}
		private System.Windows.Forms.Label lblResultado;
		private System.Windows.Forms.Button btnCalculaProm;
		private System.Windows.Forms.TextBox txtCalificacion6;
		private System.Windows.Forms.TextBox txtCalificacion7;
		private System.Windows.Forms.TextBox txtCalificacion5;
		private System.Windows.Forms.TextBox txtCalificacion4;
		private System.Windows.Forms.TextBox txtCalificacion3;
		private System.Windows.Forms.TextBox txtCalificacion2;
		private System.Windows.Forms.TextBox txtCalificacion1;
		private System.Windows.Forms.Label lblCalificacion7;
		private System.Windows.Forms.Label lblCalificacion6;
		private System.Windows.Forms.Label lblCalificacion5;
		private System.Windows.Forms.Label lblCalificacion4;
		private System.Windows.Forms.Label lblCalificacion3;
		private System.Windows.Forms.Label lblCalificacion2;
		private System.Windows.Forms.Label lblCalificacion1;
	}
}
